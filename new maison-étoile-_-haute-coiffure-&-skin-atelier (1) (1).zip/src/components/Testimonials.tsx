import React, { useState } from 'react';
import { Star, CheckCircle, MessageSquareQuote, Plus, Sparkles, X } from 'lucide-react';
import { Review } from '../types';

interface TestimonialsProps {
  reviews: Review[];
  onAddReview: (review: Omit<Review, 'id' | 'verified'>) => void;
}

export const Testimonials: React.FC<TestimonialsProps> = ({ reviews, onAddReview }) => {
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [name, setName] = useState('');
  const [service, setService] = useState('Pure Organic Nanoplastia Glass Hair System');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim()) return;
    onAddReview({
      author: name.trim(),
      serviceName: service,
      rating,
      date: 'Just now',
      comment: comment.trim()
    });
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setShowReviewModal(false);
      setName('');
      setComment('');
    }, 1500);
  };

  return (
    <section id="reviews" className="bg-[#FDFBF7] py-20 border-b border-[#E6E1D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header with Google Aggregate Rating Badge */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-12 pb-6 border-b border-[#E2DDD3]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355] mb-1">
              <Sparkles className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>Verified Client Experiences</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#171614] font-medium">
              What Discerning Clients Say
            </h2>
          </div>

          <div className="mt-4 lg:mt-0 flex flex-wrap items-center gap-4">
            {/* Google Rating Block */}
            <div className="bg-[#FAF8F3] px-4 py-2 rounded-xl border border-[#E6E1D8] flex items-center gap-3">
              <div className="flex items-center">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className="w-4 h-4 fill-[#C5A880] text-[#C5A880]" />
                ))}
              </div>
              <div className="text-left text-xs">
                <span className="font-bold text-[#171614]">4.9 out of 5</span>
                <span className="text-[#70685D] block">Based on 2,480+ Google Reviews</span>
              </div>
            </div>

            <button
              onClick={() => setShowReviewModal(true)}
              className="px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#171614] hover:bg-[#F2EDE2] border border-[#D9D2C5] rounded-xl flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4 text-[#8C7355]" />
              <span>Leave a Review</span>
            </button>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-[#FAF8F3] p-7 rounded-2xl border border-[#E6E1D8] shadow-sm flex flex-col justify-between hover:border-[#C5A880]/60 transition-colors"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#EAE4D7] text-[#171614] font-serif font-semibold text-sm flex items-center justify-center border border-[#D9D2C5]">
                      {rev.avatarText || rev.author.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-sm text-[#171614]">{rev.author}</span>
                        {rev.verified && (
                          <span title="Verified Client Visit">
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-700" />
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-[#8C7355] block">{rev.serviceName}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="flex items-center gap-0.5">
                      {Array.from({ length: rev.rating }).map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-[#C5A880] text-[#C5A880]" />
                      ))}
                    </div>
                    <span className="text-[11px] text-[#70685D] block mt-0.5">{rev.date}</span>
                  </div>
                </div>

                <p className="text-sm text-[#554F47] leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-[#EFECE6] flex items-center justify-between text-[11px] text-[#8C7355]">
                <span>Verified Google Review</span>
                <span className="text-[#70685D]">Consultation + VIP Suite</span>
              </div>
            </div>
          ))}
        </div>

        {/* Modal to Leave Review */}
        {showReviewModal && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#FDFBF7] border border-[#D9D2C5] rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
              <button
                onClick={() => setShowReviewModal(false)}
                className="absolute top-4 right-4 text-[#8C7355] hover:text-[#171614]"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="font-serif text-2xl text-[#171614] font-medium mb-1">
                Share Your Atelier Experience
              </h3>
              <p className="text-xs text-[#70685D] mb-4">
                Your feedback helps us maintain our uncompromising standards of luxury.
              </p>

              {submitted ? (
                <div className="py-8 text-center text-emerald-800">
                  <CheckCircle className="w-10 h-10 mx-auto mb-2 text-emerald-700" />
                  <p className="font-semibold text-sm">Thank You for Your Feedback</p>
                  <p className="text-xs text-[#70685D] mt-1">Your review has been verified and added.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Your Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Genevieve Laurent"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Treatment Received
                    </label>
                    <input
                      type="text"
                      required
                      value={service}
                      onChange={(e) => setService(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Rating
                    </label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setRating(num)}
                          className="p-1 hover:scale-110 transition-transform"
                        >
                          <Star
                            className={`w-6 h-6 ${
                              num <= rating
                                ? 'fill-[#C5A880] text-[#C5A880]'
                                : 'text-[#D9D2C5]'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Your Review & Experience
                    </label>
                    <textarea
                      required
                      rows={4}
                      placeholder="Describe your session, the artisan who assisted you, and your outcome..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div className="pt-2 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowReviewModal(false)}
                      className="px-4 py-2 text-xs font-medium text-[#70685D]"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] rounded hover:bg-[#2C2926]"
                    >
                      Publish Review
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
