import React, { useState, useEffect } from 'react';
import {
  X, Shield, Users, Calendar, DollarSign, Sparkles, Clock, Check, Plus, Edit2, Trash2,
  Search, Eye, EyeOff, MessageSquare, AlertCircle, RefreshCw, Star, Tag, CheckCircle2
} from 'lucide-react';
import { Service, Staff, Appointment, SpecialOffer, Review, ContactMessage, ServiceCategory, AppointmentStatus } from '../types';
import { SalonStorage } from '../lib/storage';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  onDataChanged: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ isOpen, onClose, onDataChanged }) => {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(true);
  const [adminPasscode, setAdminPasscode] = useState('');
  const [activeTab, setActiveTab] = useState<'overview' | 'appointments' | 'services' | 'staff' | 'offers' | 'reviews' | 'inbox'>('overview');

  // Loaded data
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<Staff[]>([]);
  const [offers, setOffers] = useState<SpecialOffer[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);

  // Modals & form state
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [isAddingService, setIsAddingService] = useState(false);
  const [editingStaff, setEditingStaff] = useState<Staff | null>(null);
  const [isAddingStaff, setIsAddingStaff] = useState(false);
  const [serviceSearch, setServiceSearch] = useState('');
  const [appointmentSearch, setAppointmentSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Refresh data function
  const reloadData = () => {
    setAppointments(SalonStorage.getAppointments());
    setServices(SalonStorage.getServices());
    setStaff(SalonStorage.getStaff());
    setOffers(SalonStorage.getOffers());
    setReviews(SalonStorage.getReviews());
    setMessages(SalonStorage.getContactMessages());
  };

  useEffect(() => {
    if (isOpen) {
      reloadData();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Compute Analytics KPIs
  const totalRevenue = appointments
    .filter((a) => a.status !== 'cancelled')
    .reduce((sum, a) => sum + (a.totalPrice || 0), 0);

  const todayIso = new Date().toISOString().split('T')[0];
  const todayAppointments = appointments.filter((a) => a.appointmentDate === todayIso);
  const activeStaffCount = staff.filter((s) => s.isAvailable).length;
  const unreadMessagesCount = messages.filter((m) => m.status === 'unread').length;

  // Appointment Status Change
  const handleStatusChange = (id: string, newStatus: AppointmentStatus) => {
    SalonStorage.updateAppointmentStatus(id, newStatus);
    reloadData();
    onDataChanged();
  };

  // Service Management Handlers
  const handleSaveService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingService) return;

    if (isAddingService) {
      SalonStorage.addService({
        name: editingService.name,
        category: editingService.category,
        description: editingService.description,
        price: Number(editingService.price),
        durationMinutes: Number(editingService.durationMinutes),
        suitableFor: editingService.suitableFor,
        isActive: editingService.isActive,
        benefits: editingService.benefits || []
      });
    } else {
      SalonStorage.updateService({
        ...editingService,
        price: Number(editingService.price),
        durationMinutes: Number(editingService.durationMinutes)
      });
    }

    setEditingService(null);
    setIsAddingService(false);
    reloadData();
    onDataChanged();
  };

  const handleToggleServiceActive = (srv: Service) => {
    SalonStorage.updateService({
      ...srv,
      isActive: !srv.isActive
    });
    reloadData();
    onDataChanged();
  };

  const handleDeleteService = (id: string) => {
    if (confirm('Are you certain you wish to delete this service from the atelier menu?')) {
      SalonStorage.deleteService(id);
      reloadData();
      onDataChanged();
    }
  };

  // Staff Management Handlers
  const handleToggleStaffAvailable = (member: Staff) => {
    SalonStorage.updateStaff({
      ...member,
      isAvailable: !member.isAvailable
    });
    reloadData();
    onDataChanged();
  };

  const handleSaveStaff = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStaff) return;

    if (isAddingStaff) {
      SalonStorage.addStaff({
        name: editingStaff.name,
        title: editingStaff.title,
        specialization: editingStaff.specialization,
        bio: editingStaff.bio,
        photoUrl: editingStaff.photoUrl,
        services: editingStaff.services,
        workingDays: editingStaff.workingDays,
        workingHours: editingStaff.workingHours,
        rating: 5.0,
        reviewsCount: 1,
        isAvailable: true
      });
    } else {
      SalonStorage.updateStaff(editingStaff);
    }

    setEditingStaff(null);
    setIsAddingStaff(false);
    reloadData();
    onDataChanged();
  };

  // Message status handler
  const handleMessageStatus = (id: string, status: 'read' | 'contacted') => {
    SalonStorage.updateContactStatus(id, status);
    reloadData();
    onDataChanged();
  };

  // All Category List for Dropdowns
  const ALL_CATEGORIES: ServiceCategory[] = [
    'Haircut', 'Hair Wash', 'Hair Styling', 'Hair Colour', 'Highlights',
    'Balayage/Ombre', 'Hair Treatment', 'Hair Straightening', 'Rebonding',
    'Nanoplastia', 'Facial', 'Medifacial', 'Skin Treatments', 'Threading',
    'Waxing', 'Bleach', 'Body Massage', 'Spa', 'Manicure', 'Pedicure',
    'Makeup', 'Bridal Makeup', 'Grooming'
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-2 sm:p-6 overflow-y-auto">
      <div className="bg-[#FAF8F3] border border-[#D9D2C5] rounded-2xl max-w-6xl w-full my-6 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] text-left">
        {/* Top Control Bar */}
        <div className="px-6 py-4 bg-[#171614] text-white flex items-center justify-between border-b border-[#2C2926]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#C5A880] text-[#171614] flex items-center justify-center font-bold">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-serif text-xl font-medium tracking-tight">
                  Maison Étoile Executive Console
                </h2>
                <span className="text-[10px] bg-[#C5A880]/20 text-[#E6CBA8] px-2 py-0.5 rounded border border-[#C5A880]/30 font-mono">
                  SECURE ADMIN
                </span>
              </div>
              <p className="text-xs text-[#A89F91]">
                Live reservations, pricing architecture, artisan rosters, and client inquiries
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={reloadData}
              className="p-2 text-[#A89F91] hover:text-white rounded-lg transition-colors cursor-pointer"
              title="Refresh Data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-[#A89F91] hover:text-white hover:bg-[#2C2926] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Sub Navigation Bar */}
        <div className="px-6 bg-[#F2EDE2] border-b border-[#E0DBD0] flex items-center gap-1 overflow-x-auto text-xs font-medium py-1.5">
          {[
            { id: 'overview', label: 'Executive Overview' },
            { id: 'appointments', label: `Appointments (${appointments.length})` },
            { id: 'services', label: `Services Menu (${services.length})` },
            { id: 'staff', label: `Artisans (${staff.length})` },
            { id: 'offers', label: `Packages & Offers (${offers.length})` },
            { id: 'reviews', label: `Client Reviews (${reviews.length})` },
            { id: 'inbox', label: `Concierge Inbox (${unreadMessagesCount} unread)` }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-[#171614] text-white shadow-sm font-semibold'
                  : 'text-[#554F47] hover:text-[#171614] hover:bg-[#EAE4D7]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Main Content Area */}
        <div className="p-6 overflow-y-auto flex-1 bg-[#FAF8F3]">
          {/* TAB 1: EXECUTIVE OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-8">
              {/* KPI Statistics Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-[#FDFBF7] p-5 rounded-xl border border-[#E6E1D8] shadow-sm">
                  <div className="flex items-center justify-between text-xs text-[#8C7355] font-semibold mb-1">
                    <span>TOTAL BOOKINGS</span>
                    <Calendar className="w-4 h-4 text-[#8C7355]" />
                  </div>
                  <span className="font-serif text-3xl font-semibold text-[#171614] tabular-nums block">
                    {appointments.length}
                  </span>
                  <span className="text-[11px] text-emerald-700 font-medium">98.4% confirmation rate</span>
                </div>

                <div className="bg-[#FDFBF7] p-5 rounded-xl border border-[#E6E1D8] shadow-sm">
                  <div className="flex items-center justify-between text-xs text-[#8C7355] font-semibold mb-1">
                    <span>TODAY'S SCHEDULE</span>
                    <Clock className="w-4 h-4 text-[#8C7355]" />
                  </div>
                  <span className="font-serif text-3xl font-semibold text-[#171614] tabular-nums block">
                    {todayAppointments.length}
                  </span>
                  <span className="text-[11px] text-[#70685D] font-medium">All VIP suites staffed</span>
                </div>

                <div className="bg-[#FDFBF7] p-5 rounded-xl border border-[#E6E1D8] shadow-sm">
                  <div className="flex items-center justify-between text-xs text-[#8C7355] font-semibold mb-1">
                    <span>BOOKED VOLUME</span>
                    <DollarSign className="w-4 h-4 text-[#8C7355]" />
                  </div>
                  <span className="font-serif text-3xl font-semibold text-[#171614] tabular-nums block">
                    ${totalRevenue.toLocaleString()}
                  </span>
                  <span className="text-[11px] text-[#70685D] font-medium">Average ticket: $185</span>
                </div>

                <div className="bg-[#FDFBF7] p-5 rounded-xl border border-[#E6E1D8] shadow-sm">
                  <div className="flex items-center justify-between text-xs text-[#8C7355] font-semibold mb-1">
                    <span>ACTIVE ARTISANS</span>
                    <Users className="w-4 h-4 text-[#8C7355]" />
                  </div>
                  <span className="font-serif text-3xl font-semibold text-[#171614] tabular-nums block">
                    {activeStaffCount} / {staff.length}
                  </span>
                  <span className="text-[11px] text-emerald-700 font-medium">100% attendance</span>
                </div>
              </div>

              {/* Today's Live Agenda */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-serif text-xl font-medium text-[#171614]">
                      Today's Live Atelier Schedule ({todayIso})
                    </h3>
                    <p className="text-xs text-[#70685D]">
                      Update client arrival, session start, and checkout status in real-time.
                    </p>
                  </div>
                </div>

                {todayAppointments.length === 0 ? (
                  <div className="p-8 bg-[#FDFBF7] rounded-xl border border-dashed border-[#D9D2C5] text-center text-xs text-[#70685D]">
                    No reservations scheduled for today. Check upcoming appointments tab for tomorrow's roster.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {todayAppointments.map((apt) => (
                      <div
                        key={apt.id}
                        className="bg-[#FDFBF7] p-4 rounded-xl border border-[#E6E1D8] flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                      >
                        <div className="flex items-center gap-4">
                          <span className="font-mono font-bold text-sm text-[#171614] bg-[#F2EDE2] px-2.5 py-1 rounded border border-[#DFD9CE]">
                            {apt.appointmentTime}
                          </span>
                          <div>
                            <span className="font-bold text-sm text-[#171614] block">
                              {apt.customerName}
                            </span>
                            <span className="text-[#8C7355] font-medium">
                              {apt.serviceName} · Artisan: {apt.staffName}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="font-serif font-bold text-base text-[#171614] tabular-nums">
                            ${apt.totalPrice}
                          </span>

                          <select
                            value={apt.status}
                            onChange={(e) => handleStatusChange(apt.id, e.target.value as any)}
                            className="px-2.5 py-1 bg-white border border-[#D9D2C5] rounded text-xs font-semibold focus:outline-none"
                          >
                            <option value="confirmed">Confirmed</option>
                            <option value="in-progress">In-Progress</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: APPOINTMENTS MANAGEMENT */}
          {activeTab === 'appointments' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-[#8C7355] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search by customer, booking ref, or specialist..."
                    value={appointmentSearch}
                    onChange={(e) => setAppointmentSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs bg-[#FDFBF7] border border-[#D9D2C5] rounded-lg focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="text-[#8C7355] font-semibold">Filter Status:</span>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-2.5 py-1.5 bg-[#FDFBF7] border border-[#D9D2C5] rounded-lg font-medium"
                  >
                    <option value="all">All ({appointments.length})</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="in-progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              {/* Table */}
              <div className="bg-[#FDFBF7] rounded-xl border border-[#E6E1D8] overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-[#F5F2EB] text-[#8C7355] uppercase font-semibold text-[10px] tracking-wider border-b border-[#E6E1D8]">
                      <tr>
                        <th className="px-4 py-3">Ref</th>
                        <th className="px-4 py-3">Client</th>
                        <th className="px-4 py-3">Service</th>
                        <th className="px-4 py-3">Artisan</th>
                        <th className="px-4 py-3">Date & Time</th>
                        <th className="px-4 py-3">Price</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#EFECE6]">
                      {appointments
                        .filter((a) => {
                          if (statusFilter !== 'all' && a.status !== statusFilter) return false;
                          if (appointmentSearch.trim()) {
                            const q = appointmentSearch.toLowerCase();
                            return (
                              a.customerName.toLowerCase().includes(q) ||
                              a.bookingReference.toLowerCase().includes(q) ||
                              a.serviceName.toLowerCase().includes(q) ||
                              a.staffName.toLowerCase().includes(q)
                            );
                          }
                          return true;
                        })
                        .map((apt) => (
                          <tr key={apt.id} className="hover:bg-[#FAF8F3] transition-colors">
                            <td className="px-4 py-3 font-mono font-bold text-[#8C7355]">
                              {apt.bookingReference}
                            </td>
                            <td className="px-4 py-3">
                              <span className="font-semibold text-[#171614] block">{apt.customerName}</span>
                              <span className="text-[11px] text-[#70685D]">{apt.customerPhone}</span>
                            </td>
                            <td className="px-4 py-3 font-medium text-[#171614] max-w-xs truncate">
                              {apt.serviceName}
                            </td>
                            <td className="px-4 py-3 text-[#554F47]">{apt.staffName}</td>
                            <td className="px-4 py-3 tabular-nums">
                              {apt.appointmentDate} <span className="text-[#8C7355]">· {apt.appointmentTime}</span>
                            </td>
                            <td className="px-4 py-3 font-semibold text-[#171614] tabular-nums font-serif text-sm">
                              ${apt.totalPrice}
                            </td>
                            <td className="px-4 py-3">
                              <select
                                value={apt.status}
                                onChange={(e) => handleStatusChange(apt.id, e.target.value as any)}
                                className={`text-[11px] px-2 py-0.5 rounded font-medium border ${
                                  apt.status === 'confirmed'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                    : apt.status === 'in-progress'
                                    ? 'bg-amber-50 text-amber-800 border-amber-300'
                                    : apt.status === 'completed'
                                    ? 'bg-slate-100 text-slate-800 border-slate-300'
                                    : 'bg-rose-50 text-rose-800 border-rose-300'
                                }`}
                              >
                                <option value="confirmed">Confirmed</option>
                                <option value="in-progress">In-Progress</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                              </select>
                            </td>
                            <td className="px-4 py-3 text-right">
                              <button
                                onClick={() => handleStatusChange(apt.id, 'cancelled')}
                                className="text-rose-700 hover:text-rose-900 font-medium"
                              >
                                Cancel
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SERVICES MANAGEMENT */}
          {activeTab === 'services' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-[#8C7355] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search treatment catalog..."
                    value={serviceSearch}
                    onChange={(e) => setServiceSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs bg-[#FDFBF7] border border-[#D9D2C5] rounded-lg focus:outline-none"
                  />
                </div>

                <button
                  onClick={() => {
                    setEditingService({
                      id: '',
                      name: '',
                      category: 'Haircut',
                      description: '',
                      price: 95,
                      durationMinutes: 60,
                      suitableFor: 'All hair types',
                      isActive: true,
                      benefits: []
                    });
                    setIsAddingService(true);
                  }}
                  className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] rounded flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4 text-[#C5A880]" />
                  <span>Add New Treatment</span>
                </button>
              </div>

              {/* Service Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {services
                  .filter((s) => {
                    if (!serviceSearch.trim()) return true;
                    const q = serviceSearch.toLowerCase();
                    return s.name.toLowerCase().includes(q) || s.category.toLowerCase().includes(q);
                  })
                  .map((srv) => (
                    <div
                      key={srv.id}
                      className={`p-4 rounded-xl border flex flex-col justify-between ${
                        srv.isActive ? 'bg-[#FDFBF7] border-[#E6E1D8]' : 'bg-[#F2EDE2]/60 border-[#D9D2C5] opacity-70'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between text-xs text-[#8C7355] mb-1">
                          <span className="font-semibold">{srv.category}</span>
                          <span className="tabular-nums">{srv.durationMinutes} mins</span>
                        </div>
                        <h4 className="font-serif text-lg font-medium text-[#171614] leading-snug">
                          {srv.name}
                        </h4>
                        <p className="text-xs text-[#665E53] line-clamp-2 mt-1">
                          {srv.description}
                        </p>
                      </div>

                      <div className="pt-3 mt-3 border-t border-[#EFECE6] flex items-center justify-between">
                        <span className="font-serif text-xl font-bold text-[#171614] tabular-nums">
                          ${srv.price}
                        </span>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleToggleServiceActive(srv)}
                            className="p-1.5 text-[#70685D] hover:text-[#171614] rounded hover:bg-[#F2EDE2]"
                            title={srv.isActive ? 'Disable Service' : 'Enable Service'}
                          >
                            {srv.isActive ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4 text-rose-600" />}
                          </button>
                          <button
                            onClick={() => {
                              setEditingService(srv);
                              setIsAddingService(false);
                            }}
                            className="p-1.5 text-[#8C7355] hover:text-[#171614] rounded hover:bg-[#F2EDE2]"
                            title="Edit Service Specs"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteService(srv.id)}
                            className="p-1.5 text-rose-700 hover:text-rose-900 rounded hover:bg-rose-50"
                            title="Delete Service"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* TAB 4: STAFF MANAGEMENT */}
          {activeTab === 'staff' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <p className="text-xs text-[#70685D]">
                  Configure artisan schedules, specializations, and daily booking availability.
                </p>
                <button
                  onClick={() => {
                    setEditingStaff({
                      id: '',
                      name: '',
                      title: 'Senior Artisan',
                      specialization: 'Haute Haircut & Styling',
                      bio: '',
                      photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
                      services: ['Haircut', 'Hair Styling'],
                      workingDays: [1, 2, 3, 4, 5],
                      workingHours: { start: '09:30', end: '19:00' },
                      rating: 5.0,
                      reviewsCount: 1,
                      isAvailable: true
                    });
                    setIsAddingStaff(true);
                  }}
                  className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] rounded flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4 text-[#C5A880]" />
                  <span>Add New Artisan</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {staff.map((member) => (
                  <div
                    key={member.id}
                    className="bg-[#FDFBF7] p-5 rounded-xl border border-[#E6E1D8] shadow-sm flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <img
                          src={member.photoUrl}
                          alt={member.name}
                          className="w-12 h-12 rounded-full object-cover object-top border border-[#D9D2C5]"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <h4 className="font-serif text-lg font-medium text-[#171614]">{member.name}</h4>
                          <span className="text-xs text-[#8C7355] block">{member.title}</span>
                        </div>
                      </div>

                      <div className="space-y-1.5 text-xs text-[#554F47]">
                        <p><strong>Specialty: </strong>{member.specialization}</p>
                        <p><strong>Hours: </strong>{member.workingHours.start} – {member.workingHours.end}</p>
                        <p><strong>Rating: </strong>★ {member.rating} ({member.reviewsCount} reviews)</p>
                      </div>
                    </div>

                    <div className="pt-3 mt-3 border-t border-[#EFECE6] flex items-center justify-between">
                      <button
                        onClick={() => handleToggleStaffAvailable(member)}
                        className={`text-xs px-2.5 py-1 rounded font-medium ${
                          member.isAvailable
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                            : 'bg-rose-50 text-rose-800 border border-rose-300'
                        }`}
                      >
                        {member.isAvailable ? 'Active for Bookings' : 'Unavailable / On Leave'}
                      </button>

                      <button
                        onClick={() => {
                          setEditingStaff(member);
                          setIsAddingStaff(false);
                        }}
                        className="p-1.5 text-[#8C7355] hover:text-[#171614]"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: PACKAGES & OFFERS */}
          {activeTab === 'offers' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {offers.map((offer) => (
                  <div key={offer.id} className="bg-[#FDFBF7] p-5 rounded-xl border border-[#E6E1D8] shadow-sm">
                    <span className="text-[10px] uppercase font-bold text-[#8C7355] block mb-1">
                      {offer.badge}
                    </span>
                    <h4 className="font-serif text-lg font-medium text-[#171614]">{offer.title}</h4>
                    <p className="text-xs text-[#665E53] mt-1 mb-3 line-clamp-2">{offer.description}</p>
                    <div className="flex items-baseline gap-2 mb-3">
                      <span className="font-serif text-2xl font-bold text-[#171614]">${offer.offerPrice}</span>
                      <span className="text-xs text-[#8C7355] line-through">${offer.originalPrice}</span>
                    </div>
                    <span className="text-[11px] text-[#70685D] block">Valid Until: {offer.validUntil}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: REVIEWS MODERATION */}
          {activeTab === 'reviews' && (
            <div className="space-y-3">
              {reviews.map((rev) => (
                <div key={rev.id} className="bg-[#FDFBF7] p-4 rounded-xl border border-[#E6E1D8] flex justify-between items-start text-xs">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-sm text-[#171614]">{rev.author}</span>
                      <span className="text-[#8C7355]">· {rev.serviceName}</span>
                      <span className="text-amber-500 font-bold">★ {rev.rating}</span>
                    </div>
                    <p className="text-[#554F47] italic">"{rev.comment}"</p>
                  </div>
                  <span className="text-[#70685D] text-[11px] shrink-0 ml-4">{rev.date}</span>
                </div>
              ))}
            </div>
          )}

          {/* TAB 7: CONCIERGE INBOX */}
          {activeTab === 'inbox' && (
            <div className="space-y-3">
              {messages.length === 0 ? (
                <div className="p-8 bg-[#FDFBF7] rounded-xl border border-dashed text-center text-xs text-[#70685D]">
                  No messages in concierge inbox.
                </div>
              ) : (
                messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`p-4 rounded-xl border text-xs space-y-2 ${
                      msg.status === 'unread' ? 'bg-[#F2EDE2] border-[#8C7355]' : 'bg-[#FDFBF7] border-[#E6E1D8]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-bold text-sm text-[#171614]">{msg.name}</span>
                        <span className="text-[#8C7355] ml-2">({msg.email} · {msg.phone})</span>
                      </div>
                      <span className="text-[11px] text-[#70685D]">{new Date(msg.createdAt).toLocaleString()}</span>
                    </div>

                    <div className="text-[11px] font-semibold text-[#8C7355]">
                      Topic: {msg.serviceInterest}
                    </div>

                    <p className="text-[#3E3A35] bg-white p-2.5 rounded border border-[#E0DBD0]">
                      "{msg.message}"
                    </p>

                    <div className="flex items-center justify-end gap-2 pt-1">
                      {msg.status === 'unread' && (
                        <button
                          onClick={() => handleMessageStatus(msg.id, 'read')}
                          className="px-3 py-1 bg-white border border-[#D9D2C5] rounded text-[11px] font-medium"
                        >
                          Mark as Read
                        </button>
                      )}
                      {msg.status !== 'contacted' && (
                        <button
                          onClick={() => handleMessageStatus(msg.id, 'contacted')}
                          className="px-3 py-1 bg-[#171614] text-white rounded text-[11px] font-medium"
                        >
                          Mark as Contacted
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* MODAL: ADD / EDIT SERVICE */}
        {editingService && (
          <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#FDFBF7] border border-[#D9D2C5] rounded-2xl max-w-lg w-full p-6 shadow-2xl relative text-left">
              <button
                onClick={() => setEditingService(null)}
                className="absolute top-4 right-4 text-[#8C7355] hover:text-[#171614]"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="font-serif text-2xl font-medium text-[#171614] mb-3">
                {isAddingService ? 'Add Atelier Treatment' : 'Modify Treatment Specifications'}
              </h3>

              <form onSubmit={handleSaveService} className="space-y-3.5 text-xs">
                <div>
                  <label className="font-semibold text-[#8C7355] block mb-1">Treatment Name *</label>
                  <input
                    type="text"
                    required
                    value={editingService.name}
                    onChange={(e) => setEditingService({ ...editingService, name: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-[#8C7355] block mb-1">Category *</label>
                    <select
                      value={editingService.category}
                      onChange={(e) => setEditingService({ ...editingService, category: e.target.value as any })}
                      className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm"
                    >
                      {ALL_CATEGORIES.map((cat) => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="font-semibold text-[#8C7355] block mb-1">Price ($ USD) *</label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={editingService.price}
                      onChange={(e) => setEditingService({ ...editingService, price: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm tabular-nums"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-[#8C7355] block mb-1">Duration (Minutes) *</label>
                    <input
                      type="number"
                      required
                      min={10}
                      step={5}
                      value={editingService.durationMinutes}
                      onChange={(e) => setEditingService({ ...editingService, durationMinutes: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm tabular-nums"
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-[#8C7355] block mb-1">Status</label>
                    <select
                      value={editingService.isActive ? 'active' : 'disabled'}
                      onChange={(e) => setEditingService({ ...editingService, isActive: e.target.value === 'active' })}
                      className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm"
                    >
                      <option value="active">Active on Menu</option>
                      <option value="disabled">Disabled</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-[#8C7355] block mb-1">Description *</label>
                  <textarea
                    rows={2}
                    required
                    value={editingService.description}
                    onChange={(e) => setEditingService({ ...editingService, description: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm"
                  />
                </div>

                <div>
                  <label className="font-semibold text-[#8C7355] block mb-1">Suitable Customer Profile</label>
                  <input
                    type="text"
                    value={editingService.suitableFor}
                    onChange={(e) => setEditingService({ ...editingService, suitableFor: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingService(null)}
                    className="px-4 py-2 text-xs text-[#70685D]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] rounded hover:bg-[#2C2926]"
                  >
                    Save Treatment
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL: ADD / EDIT STAFF */}
        {editingStaff && (
          <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#FDFBF7] border border-[#D9D2C5] rounded-2xl max-w-lg w-full p-6 shadow-2xl relative text-left">
              <button
                onClick={() => setEditingStaff(null)}
                className="absolute top-4 right-4 text-[#8C7355] hover:text-[#171614]"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="font-serif text-2xl font-medium text-[#171614] mb-3">
                {isAddingStaff ? 'Add Master Artisan' : 'Edit Artisan Profile'}
              </h3>

              <form onSubmit={handleSaveStaff} className="space-y-3.5 text-xs">
                <div>
                  <label className="font-semibold text-[#8C7355] block mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={editingStaff.name}
                    onChange={(e) => setEditingStaff({ ...editingStaff, name: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-[#8C7355] block mb-1">Official Title *</label>
                    <input
                      type="text"
                      required
                      value={editingStaff.title}
                      onChange={(e) => setEditingStaff({ ...editingStaff, title: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm"
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-[#8C7355] block mb-1">Photo URL *</label>
                    <input
                      type="text"
                      required
                      value={editingStaff.photoUrl}
                      onChange={(e) => setEditingStaff({ ...editingStaff, photoUrl: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-[#8C7355] block mb-1">Core Specialization</label>
                  <input
                    type="text"
                    required
                    value={editingStaff.specialization}
                    onChange={(e) => setEditingStaff({ ...editingStaff, specialization: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm"
                  />
                </div>

                <div>
                  <label className="font-semibold text-[#8C7355] block mb-1">Biography / Credentials</label>
                  <textarea
                    rows={2}
                    value={editingStaff.bio}
                    onChange={(e) => setEditingStaff({ ...editingStaff, bio: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingStaff(null)}
                    className="px-4 py-2 text-xs text-[#70685D]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] rounded hover:bg-[#2C2926]"
                  >
                    Save Artisan
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
