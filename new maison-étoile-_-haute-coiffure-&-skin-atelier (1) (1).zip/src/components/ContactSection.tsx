import React, { useState } from 'react';
import { Send, CheckCircle2, MessageSquare, Phone, Mail, Sparkles } from 'lucide-react';
import { SalonStorage } from '../lib/storage';

export const ContactSection: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [serviceInterest, setServiceInterest] = useState('Bespoke Bridal or Private VIP Suite');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;

    SalonStorage.addContactMessage({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      serviceInterest,
      message: message.trim()
    });

    setSubmitted(true);
    setTimeout(() => {
      setName('');
      setEmail('');
      setPhone('');
      setMessage('');
      setSubmitted(false);
    }, 4000);
  };

  return (
    <section id="contact" className="bg-[#F8F5EE] py-20 border-b border-[#E6E1D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Text */}
          <div className="lg:col-span-5 space-y-5 text-left">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355]">
              <MessageSquare className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>Concierge Desk</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#171614] font-medium leading-tight">
              Bespoke Inquiries & VIP Privatization
            </h2>
            <p className="text-sm text-[#554F47] leading-relaxed">
              Planning a wedding party, seeking a confidential trichological consultation, or requesting our private after-hours suite? 
              Our salon director will coordinate your reservation within two business hours.
            </p>

            <div className="pt-4 space-y-3 text-xs sm:text-sm text-[#3E3A35]">
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#8C7355]" />
                <span className="font-semibold text-[#171614]">+1 (555) 789-2341 (Direct Concierge Line)</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#8C7355]" />
                <span>concierge@maisonetoile-atelier.com</span>
              </div>
            </div>
          </div>

          {/* Right Form Card */}
          <div className="lg:col-span-7 bg-[#FDFBF7] p-8 rounded-2xl border border-[#D9D2C5] shadow-md">
            {submitted ? (
              <div className="py-12 text-center text-emerald-850">
                <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-emerald-700" />
                <h3 className="font-serif text-2xl font-medium text-[#171614]">Inquiry Received with Distinction</h3>
                <p className="text-sm text-[#665E53] mt-2 max-w-md mx-auto">
                  Thank you, {name}. A member of our concierge leadership will reach out via phone or email shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Lady Vivienne Westwood"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border border-[#D9D2C5] rounded-xl text-sm focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. vivienne@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border border-[#D9D2C5] rounded-xl text-sm focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Contact Telephone
                    </label>
                    <input
                      type="tel"
                      placeholder="e.g. +1 (555) 000-0000"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border border-[#D9D2C5] rounded-xl text-sm focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Area of Interest
                    </label>
                    <select
                      value={serviceInterest}
                      onChange={(e) => setServiceInterest(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-white border border-[#D9D2C5] rounded-xl text-sm focus:outline-none focus:border-[#8C7355]"
                    >
                      <option>Bespoke Bridal or Private VIP Suite</option>
                      <option>Organic Nanoplastia Consultation</option>
                      <option>Hydra-Infusion MediGlow Treatment Plan</option>
                      <option>Editorial Fashion or Runway Styling</option>
                      <option>Corporate Gifting & Private Atelier Buyout</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                    Your Requirements or Notes *
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Tell us about desired dates, number of guests, or hair history..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-[#D9D2C5] rounded-xl text-sm focus:outline-none focus:border-[#8C7355]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] active:scale-[0.99] transition-all rounded shadow flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5 text-[#C5A880]" />
                  <span>Transmit Inquiry to Concierge</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
