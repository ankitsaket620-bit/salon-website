import React, { useState, useEffect } from 'react';
import { X, Check, ArrowRight, ArrowLeft, Calendar, Clock, User, Sparkles, AlertCircle, Download, CheckCircle2 } from 'lucide-react';
import { Service, Staff, Appointment, UserProfile } from '../types';
import { SalonStorage } from '../lib/storage';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedServiceId?: string | null;
  preSelectedStaffId?: string | null;
  currentUser: UserProfile | null;
  onBookingComplete: (appointment: Appointment) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  preSelectedServiceId,
  preSelectedStaffId,
  currentUser,
  onBookingComplete
}) => {
  const [step, setStep] = useState<number>(1);
  const [services, setServices] = useState<Service[]>([]);
  const [staffList, setStaffList] = useState<Staff[]>([]);

  // Selection state
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedStaffId, setSelectedStaffId] = useState<string>('any-master');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');

  // Customer Details Form
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [notes, setNotes] = useState('');

  // Execution state
  const [errorMsg, setErrorMsg] = useState('');
  const [confirmedAppointment, setConfirmedAppointment] = useState<Appointment | null>(null);

  // Available slots for selected date/staff
  const [slotOptions, setSlotOptions] = useState<{ time: string; available: boolean }[]>([]);

  // Load services and staff on open
  useEffect(() => {
    if (isOpen) {
      const allServices = SalonStorage.getServices().filter((s) => s.isActive);
      const allStaff = SalonStorage.getStaff().filter((s) => s.isAvailable);
      setServices(allServices);
      setStaffList(allStaff);

      // Pre-select service if provided
      if (preSelectedServiceId) {
        const found = allServices.find((s) => s.id === preSelectedServiceId || s.name === preSelectedServiceId);
        if (found) {
          setSelectedService(found);
          setStep(2);
        }
      } else {
        setSelectedService(null);
        setStep(1);
      }

      // Pre-select staff if provided
      if (preSelectedStaffId) {
        setSelectedStaffId(preSelectedStaffId);
        if (preSelectedServiceId) setStep(3);
      } else {
        setSelectedStaffId('any-master');
      }

      // Pre-fill user data
      if (currentUser) {
        setCustomerName(currentUser.fullName);
        setCustomerEmail(currentUser.email);
        setCustomerPhone(currentUser.phone || '');
      }

      // Default date to tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      setSelectedDate(tomorrow.toISOString().split('T')[0]);
      setSelectedTime('');
      setErrorMsg('');
      setConfirmedAppointment(null);
    }
  }, [isOpen, preSelectedServiceId, preSelectedStaffId, currentUser]);

  // Compute available slots whenever staff or date changes
  useEffect(() => {
    if (selectedDate && (selectedStaffId || selectedStaffId === 'any-master')) {
      const slots = SalonStorage.getAvailableSlots(selectedStaffId, selectedDate);
      setSlotOptions(slots);
      // If current selected time is no longer available, clear it
      if (selectedTime) {
        const match = slots.find((s) => s.time === selectedTime);
        if (!match || !match.available) {
          setSelectedTime('');
        }
      }
    }
  }, [selectedStaffId, selectedDate]);

  if (!isOpen) return null;

  // Generate next 14 days for date selection
  const dateOptions = Array.from({ length: 14 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i + 1);
    const iso = d.toISOString().split('T')[0];
    const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
    const monthName = d.toLocaleDateString('en-US', { month: 'short' });
    const dayNum = d.getDate();
    return { iso, dayName, monthName, dayNum };
  });

  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService || !selectedDate || !selectedTime) {
      setErrorMsg('Please complete all selection steps.');
      return;
    }

    if (!customerName.trim() || !customerEmail.trim() || !customerPhone.trim()) {
      setErrorMsg('Please enter your full contact details.');
      return;
    }

    const res = SalonStorage.createAppointment({
      customerName: customerName.trim(),
      customerEmail: customerEmail.trim(),
      customerPhone: customerPhone.trim(),
      serviceId: selectedService.id,
      staffId: selectedStaffId,
      appointmentDate: selectedDate,
      appointmentTime: selectedTime,
      notes: notes.trim()
    });

    if (!res.success || !res.appointment) {
      setErrorMsg(res.error || 'Failed to secure time slot. It may have just been booked.');
      return;
    }

    setConfirmedAppointment(res.appointment);
    onBookingComplete(res.appointment);
    setStep(6);
  };

  const handleDownloadCalendar = () => {
    if (!confirmedAppointment) return;
    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Maison Etoile//Salon Booking//EN',
      'BEGIN:VEVENT',
      `SUMMARY:Maison Étoile - ${confirmedAppointment.serviceName}`,
      `DESCRIPTION:Appointment with ${confirmedAppointment.staffName}. Reference: ${confirmedAppointment.bookingReference}`,
      `LOCATION:Maison Étoile Atelier, 480 Haute Blvd Suite 100`,
      `STATUS:CONFIRMED`,
      'END:VEVENT',
      'END:VCALENDAR'
    ].join('\r\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `maison-etoile-${confirmedAppointment.bookingReference}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-[#FDFBF7] border border-[#D9D2C5] rounded-2xl max-w-2xl w-full my-8 shadow-2xl overflow-hidden flex flex-col relative animate-in fade-in zoom-in-95 duration-150 text-left">
        {/* Modal Top Header */}
        <div className="px-6 py-4 bg-[#FAF8F3] border-b border-[#E6E1D8] flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-[#8C7355] uppercase tracking-wider block">
              Concierge Reservation
            </span>
            <h2 className="font-serif text-xl sm:text-2xl font-medium text-[#171614]">
              {step === 6 ? 'Reservation Confirmed' : 'Book Your Atelier Experience'}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#8C7355] hover:text-[#171614] hover:bg-[#F2EDE2] transition-colors cursor-pointer"
            aria-label="Close Booking Window"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Multi-Step Progress Tracker */}
        {step < 6 && (
          <div className="px-6 py-3 bg-[#F5F2EB] border-b border-[#E6E1D8] flex items-center justify-between text-xs font-medium text-[#70685D] overflow-x-auto">
            {[
              { num: 1, label: 'Service' },
              { num: 2, label: 'Artisan' },
              { num: 3, label: 'Date' },
              { num: 4, label: 'Time' },
              { num: 5, label: 'Details' }
            ].map((st) => (
              <div
                key={st.num}
                className={`flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  step === st.num
                    ? 'text-[#171614] font-semibold'
                    : step > st.num
                    ? 'text-emerald-700'
                    : 'text-[#9C9488]'
                }`}
                onClick={() => {
                  if (st.num < step) setStep(st.num);
                }}
              >
                <span
                  className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] ${
                    step === st.num
                      ? 'bg-[#171614] text-white'
                      : step > st.num
                      ? 'bg-emerald-700 text-white'
                      : 'bg-[#E5DFD4] text-[#70685D]'
                  }`}
                >
                  {step > st.num ? <Check className="w-3 h-3" /> : st.num}
                </span>
                <span className="hidden sm:inline">{st.label}</span>
              </div>
            ))}
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {errorMsg && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* STEP 1: Select Service */}
          {step === 1 && (
            <div className="space-y-4">
              <p className="text-xs text-[#70685D]">
                Select the treatment you wish to reserve. You can customize additional options with your artisan.
              </p>

              <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                {services.map((srv) => (
                  <div
                    key={srv.id}
                    onClick={() => {
                      setSelectedService(srv);
                      setStep(2);
                      setErrorMsg('');
                    }}
                    className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      selectedService?.id === srv.id
                        ? 'bg-[#F2EDE2] border-[#171614] shadow-sm'
                        : 'bg-white border-[#E6E1D8] hover:border-[#C5A880]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2 text-xs text-[#8C7355] mb-0.5">
                        <span>{srv.category}</span>
                        <span>·</span>
                        <span className="flex items-center gap-1 tabular-nums">
                          <Clock className="w-3 h-3" /> {srv.durationMinutes} mins
                        </span>
                      </div>
                      <h4 className="font-serif text-lg font-medium text-[#171614]">{srv.name}</h4>
                      <p className="text-xs text-[#665E53] line-clamp-1 mt-0.5">{srv.description}</p>
                    </div>

                    <div className="text-right pl-4">
                      <span className="font-serif text-xl font-semibold text-[#171614] tabular-nums block">
                        ${srv.price}
                      </span>
                      <button className="mt-1 text-xs text-[#8C7355] font-semibold flex items-center gap-1 ml-auto">
                        <span>Select</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: Select Specialist */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="bg-[#FAF8F3] p-3 rounded-lg border border-[#E6E1D8] flex items-center justify-between text-xs">
                <div>
                  <span className="text-[#8C7355] font-medium block">Selected Treatment:</span>
                  <span className="font-serif text-base font-semibold text-[#171614]">{selectedService?.name}</span>
                </div>
                <span className="font-serif text-lg font-semibold text-[#171614]">${selectedService?.price}</span>
              </div>

              <p className="text-xs text-[#70685D]">
                Choose your preferred master artisan or select any available specialist for greater scheduling flexibility.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Any Master Stylist Option */}
                <div
                  onClick={() => {
                    setSelectedStaffId('any-master');
                    setStep(3);
                  }}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    selectedStaffId === 'any-master'
                      ? 'bg-[#F2EDE2] border-[#171614]'
                      : 'bg-white border-[#E6E1D8] hover:border-[#C5A880]'
                  }`}
                >
                  <div className="w-10 h-10 rounded-full bg-[#171614] text-[#C5A880] flex items-center justify-center font-semibold mb-2">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <h4 className="font-serif text-base font-medium text-[#171614]">Any Master Artisan</h4>
                  <p className="text-xs text-[#665E53] mt-1">
                    First available senior stylist certified in {selectedService?.category}. Maximum availability.
                  </p>
                </div>

                {/* Specific Staff */}
                {staffList.map((st) => (
                  <div
                    key={st.id}
                    onClick={() => {
                      setSelectedStaffId(st.id);
                      setStep(3);
                    }}
                    className={`p-4 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                      selectedStaffId === st.id
                        ? 'bg-[#F2EDE2] border-[#171614]'
                        : 'bg-white border-[#E6E1D8] hover:border-[#C5A880]'
                    }`}
                  >
                    <img
                      src={st.photoUrl}
                      alt={st.name}
                      className="w-12 h-12 rounded-full object-cover object-top border border-[#D9D2C5]"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <h4 className="font-serif text-base font-medium text-[#171614]">{st.name}</h4>
                      <p className="text-[11px] text-[#8C7355]">{st.title}</p>
                      <p className="text-[11px] text-[#665E53] mt-1 line-clamp-2">{st.specialization}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2 text-xs font-medium text-[#554F47] flex items-center gap-1 hover:text-[#171614]"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back to Services
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Select Date */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="bg-[#FAF8F3] p-3 rounded-lg border border-[#E6E1D8] flex items-center justify-between text-xs">
                <div>
                  <span className="text-[#8C7355]">Treatment: </span>
                  <strong className="text-[#171614]">{selectedService?.name}</strong>
                </div>
                <div>
                  <span className="text-[#8C7355]">Specialist: </span>
                  <strong className="text-[#171614]">
                    {selectedStaffId === 'any-master'
                      ? 'Any Master Artisan'
                      : staffList.find((s) => s.id === selectedStaffId)?.name}
                  </strong>
                </div>
              </div>

              <p className="text-xs text-[#70685D]">
                Select your preferred date for the appointment.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5">
                {dateOptions.map((opt) => (
                  <button
                    key={opt.iso}
                    type="button"
                    onClick={() => {
                      setSelectedDate(opt.iso);
                      setStep(4);
                    }}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      selectedDate === opt.iso
                        ? 'bg-[#171614] text-white border-[#171614] shadow-md'
                        : 'bg-white border-[#E6E1D8] text-[#171614] hover:border-[#C5A880]'
                    }`}
                  >
                    <span className="text-[10px] uppercase font-semibold text-[#8C7355] block">
                      {opt.dayName}
                    </span>
                    <span className="font-serif text-2xl font-bold block my-0.5 tabular-nums">
                      {opt.dayNum}
                    </span>
                    <span className="text-[10px] text-[#70685D] block">{opt.monthName}</span>
                  </button>
                ))}
              </div>

              <div className="pt-2 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2 text-xs font-medium text-[#554F47] flex items-center gap-1 hover:text-[#171614]"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back to Artisan
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Select Time Slot (Prevents Double Booking) */}
          {step === 4 && (
            <div className="space-y-4">
              <div className="bg-[#FAF8F3] p-3 rounded-lg border border-[#E6E1D8] flex items-center justify-between text-xs">
                <div>
                  <span className="text-[#8C7355]">Date Selected: </span>
                  <strong className="text-[#171614]">{selectedDate}</strong>
                </div>
                <div>
                  <span className="text-[#8C7355]">Duration: </span>
                  <strong className="text-[#171614]">{selectedService?.durationMinutes} mins</strong>
                </div>
              </div>

              <p className="text-xs text-[#70685D]">
                Select an open time slot. Fully booked slots are blocked to ensure zero wait time and no overlapping sessions.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {slotOptions.map((slot) => (
                  <button
                    key={slot.time}
                    type="button"
                    disabled={!slot.available}
                    onClick={() => {
                      if (slot.available) {
                        setSelectedTime(slot.time);
                        setStep(5);
                      }
                    }}
                    className={`py-3 px-4 rounded-xl border text-xs font-medium transition-all flex items-center justify-between ${
                      !slot.available
                        ? 'bg-[#F2EDE2]/50 text-[#A8A196] border-[#E8E2D7] cursor-not-allowed line-through'
                        : selectedTime === slot.time
                        ? 'bg-[#171614] text-white border-[#171614] shadow'
                        : 'bg-white text-[#171614] border-[#E6E1D8] hover:border-[#C5A880] cursor-pointer'
                    }`}
                  >
                    <span className="tabular-nums">{slot.time}</span>
                    <span className="text-[10px]">
                      {slot.available ? 'Available' : 'Reserved'}
                    </span>
                  </button>
                ))}
              </div>

              <div className="pt-2 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-4 py-2 text-xs font-medium text-[#554F47] flex items-center gap-1 hover:text-[#171614]"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back to Date
                </button>
              </div>
            </div>
          )}

          {/* STEP 5: Customer Details */}
          {step === 5 && (
            <form onSubmit={handleConfirmBooking} className="space-y-4">
              {/* Summary Card */}
              <div className="bg-[#FAF8F3] p-4 rounded-xl border border-[#D9D2C5] text-xs space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-[#8C7355]">Treatment:</span>
                  <span className="font-semibold text-[#171614]">{selectedService?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8C7355]">Artisan:</span>
                  <span className="font-semibold text-[#171614]">
                    {selectedStaffId === 'any-master'
                      ? 'Any Master Artisan'
                      : staffList.find((s) => s.id === selectedStaffId)?.name}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8C7355]">Date & Time:</span>
                  <span className="font-semibold text-[#171614] tabular-nums">
                    {selectedDate} at {selectedTime}
                  </span>
                </div>
                <div className="flex justify-between pt-1 border-t border-[#EFECE6] text-sm">
                  <span className="font-semibold text-[#171614]">Total Investment:</span>
                  <span className="font-serif font-bold text-lg text-[#171614] tabular-nums">
                    ${selectedService?.price}
                  </span>
                </div>
                <p className="text-[11px] text-[#70685D] italic">
                  * No pre-payment required online. Settled in person at the conclusion of your atelier session.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                    First & Last Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Victoria Sterling"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                    Email Address (For Confirmation) *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="e.g. victoria@example.com"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                  Mobile Telephone (For SMS Reminders) *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. +1 (555) 234-5678"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                  Hair / Skin Consultation Notes & Special Preferences
                </label>
                <textarea
                  rows={3}
                  placeholder="Mention any sensitivities, allergies, hair history (e.g. previous bleach, nanoplastia), or hot drink preferences..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                />
              </div>

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(4)}
                  className="px-4 py-2 text-xs font-medium text-[#554F47] flex items-center gap-1 hover:text-[#171614]"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back to Time
                </button>

                <button
                  type="submit"
                  className="px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] active:scale-[0.99] transition-all rounded shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4 text-[#C5A880]" />
                  <span>Confirm Reservation</span>
                </button>
              </div>
            </form>
          )}

          {/* STEP 6: Confirmation Receipt */}
          {step === 6 && confirmedAppointment && (
            <div className="space-y-6 text-center py-4">
              <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center mx-auto">
                <Check className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355]">
                  Reservation Confirmed
                </span>
                <h3 className="font-serif text-3xl font-medium text-[#171614] mt-1">
                  We Look Forward to Welcoming You
                </h3>
                <p className="text-xs sm:text-sm text-[#665E53] mt-2 max-w-md mx-auto">
                  A confirmation summary has been logged for {confirmedAppointment.customerName}. 
                  You can reschedule or view this reservation anytime in your customer account.
                </p>
              </div>

              {/* Receipt Box */}
              <div className="bg-[#FAF8F3] border border-[#D9D2C5] rounded-xl p-6 text-left max-w-md mx-auto space-y-3 text-xs sm:text-sm">
                <div className="flex justify-between items-center pb-2 border-b border-[#EFECE6]">
                  <span className="text-[#8C7355] font-semibold">Booking Reference</span>
                  <span className="font-mono font-bold text-base text-[#171614] bg-[#F2EDE2] px-2.5 py-1 rounded border border-[#DFD9CE]">
                    {confirmedAppointment.bookingReference}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-[#8C7355]">Treatment:</span>
                  <span className="font-semibold text-[#171614] text-right">{confirmedAppointment.serviceName}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-[#8C7355]">Artisan:</span>
                  <span className="font-semibold text-[#171614]">{confirmedAppointment.staffName}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-[#8C7355]">Scheduled Date:</span>
                  <span className="font-semibold text-[#171614] tabular-nums">{confirmedAppointment.appointmentDate}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-[#8C7355]">Scheduled Time:</span>
                  <span className="font-semibold text-[#171614] tabular-nums">{confirmedAppointment.appointmentTime}</span>
                </div>

                <div className="flex justify-between pt-2 border-t border-[#EFECE6] text-base">
                  <span className="font-semibold text-[#171614]">Session Total:</span>
                  <span className="font-serif font-bold text-xl text-[#171614] tabular-nums">${confirmedAppointment.totalPrice}</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <button
                  onClick={handleDownloadCalendar}
                  className="w-full sm:w-auto px-5 py-2.5 text-xs font-semibold text-[#171614] bg-[#F2EDE2] hover:bg-[#EAE4D7] border border-[#D9D2C5] rounded flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-[#8C7355]" />
                  <span>Add to Calendar (.ics)</span>
                </button>

                <button
                  onClick={onClose}
                  className="w-full sm:w-auto px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] rounded shadow cursor-pointer"
                >
                  Return to Atelier
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
