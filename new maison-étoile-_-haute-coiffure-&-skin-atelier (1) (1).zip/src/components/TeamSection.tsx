import React from 'react';
import { Star, ArrowRight, Sparkles, Award } from 'lucide-react';
import { Staff } from '../types';

interface TeamSectionProps {
  staff: Staff[];
  onBookWithStaff: (staffId: string) => void;
}

export const TeamSection: React.FC<TeamSectionProps> = ({ staff, onBookWithStaff }) => {
  return (
    <section id="team" className="bg-[#FAF8F3] py-20 border-b border-[#E6E1D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#E2DDD3]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355] mb-1">
              <Award className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>International Artisans</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#171614] font-medium">
              Meet the Master Stylists & Aestheticians
            </h2>
          </div>
          <p className="text-sm text-[#70685D] max-w-md mt-2 md:mt-0">
            Formally trained across Paris, London, Milan, and Beverly Hills. 
            Each artisan specializes in distinct disciplines to ensure exceptional execution.
          </p>
        </div>

        {/* Staff Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {staff.map((member) => (
            <div
              key={member.id}
              className="bg-[#FDFBF7] rounded-2xl border border-[#E6E1D8] overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Staff Portrait */}
                <div className="relative aspect-[4/3] bg-[#EFECE6] overflow-hidden">
                  <img
                    src={member.photoUrl}
                    alt={member.name}
                    className="w-full h-full object-cover object-top group-hover:scale-[1.03] transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent" />

                  {/* Rating Tag */}
                  <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded text-xs text-white flex items-center gap-1">
                    <Star className="w-3 h-3 fill-[#C5A880] text-[#C5A880]" />
                    <span className="font-semibold tabular-nums">{member.rating}</span>
                    <span className="text-[#D9D2C5] text-[10px]">({member.reviewsCount})</span>
                  </div>

                  <div className="absolute bottom-3 left-4 text-white">
                    <h3 className="font-serif text-2xl font-medium">{member.name}</h3>
                    <p className="text-xs text-[#E6CBA8] font-medium">{member.title}</p>
                  </div>
                </div>

                {/* Details */}
                <div className="p-6">
                  <div className="mb-3">
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-[#8C7355] block">
                      Core Specialization:
                    </span>
                    <p className="text-sm text-[#171614] font-medium mt-0.5">
                      {member.specialization}
                    </p>
                  </div>

                  <p className="text-xs text-[#665E53] leading-relaxed mb-4">
                    {member.bio}
                  </p>

                  <div className="pt-3 border-t border-[#EFECE6]">
                    <span className="text-[11px] text-[#8C7355] block mb-1.5 font-medium">
                      Specialized Categories:
                    </span>
                    <div className="flex flex-wrap gap-1 text-[11px] text-[#4A453E]">
                      {member.services.map((cat, idx) => (
                        <span key={idx} className="bg-[#F5F1E8] px-2 py-0.5 rounded text-[#554F47]">
                          {cat}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Booking CTA */}
              <div className="p-6 pt-0">
                <button
                  onClick={() => onBookWithStaff(member.id)}
                  className="w-full py-2.5 text-xs font-semibold uppercase tracking-wider text-[#171614] hover:text-white bg-[#F2EDE2] hover:bg-[#171614] active:scale-[0.98] transition-all rounded flex items-center justify-center gap-2 cursor-pointer border border-[#D9D2C5]"
                >
                  <span>Book with {member.name.split(' ')[0]}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#8C7355]" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
