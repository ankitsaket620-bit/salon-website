import React from 'react';
import { MapPin, Clock, Phone, Mail, Navigation, Car, Shield, Sparkles } from 'lucide-react';

export const LocationHours: React.FC = () => {
  const schedule = [
    { days: 'Monday – Friday', hours: '9:00 AM – 8:00 PM', status: 'Regular Atelier Hours' },
    { days: 'Saturday', hours: '9:00 AM – 8:00 PM', status: 'Bridal & Weekend Styling' },
    { days: 'Sunday', hours: '10:00 AM – 6:00 PM', status: 'By Reservation Only' }
  ];

  return (
    <section id="location" className="bg-[#FDFBF7] py-20 border-b border-[#E6E1D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#E2DDD3]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355] mb-1">
              <MapPin className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>Flagship Location & Hours</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#171614] font-medium">
              Visit Our Private Sanctuary
            </h2>
          </div>
          <p className="text-sm text-[#70685D] max-w-md mt-2 md:mt-0">
            Conveniently situated in the luxury shopping promenade with private underground valet parking and dedicated elevator access.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Column: Hours & Contact Information */}
          <div className="lg:col-span-6 space-y-6">
            {/* Opening Hours Card */}
            <div className="bg-[#FAF8F3] p-7 rounded-2xl border border-[#E6E1D8] shadow-sm">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#8C7355] uppercase tracking-wider mb-4">
                <Clock className="w-4 h-4 text-[#8C7355]" />
                <span>Operating Atelier Hours</span>
              </div>

              <div className="space-y-3.5">
                {schedule.map((slot, i) => (
                  <div key={i} className="flex flex-col sm:flex-row sm:items-center justify-between py-2 border-b border-[#EFECE6] last:border-b-0">
                    <div>
                      <span className="font-serif text-lg font-medium text-[#171614]">{slot.days}</span>
                      <span className="text-[11px] text-[#8C7355] block sm:inline sm:ml-2">({slot.status})</span>
                    </div>
                    <span className="text-sm font-semibold text-[#171614] tabular-nums mt-1 sm:mt-0">
                      {slot.hours}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Address & Amenities Card */}
            <div className="bg-[#FAF8F3] p-7 rounded-2xl border border-[#E6E1D8] shadow-sm space-y-4">
              <div className="flex items-start gap-3.5">
                <MapPin className="w-5 h-5 text-[#8C7355] shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-serif text-lg font-medium text-[#171614]">Atelier Address</h3>
                  <p className="text-sm text-[#554F47] mt-0.5">
                    480 Haute Boulevard, Suite 100 · The Promenade Court<br />
                    Metropolis, NY 10021
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-[#EFECE6] flex items-start gap-3.5">
                <Car className="w-5 h-5 text-[#8C7355] shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-serif text-lg font-medium text-[#171614]">Complimentary Valet</h3>
                  <p className="text-sm text-[#554F47] mt-0.5">
                    Complimentary valet parking is provided at Entrance B. Present your reservation confirmation to the head concierge.
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-[#EFECE6] flex flex-wrap gap-4 text-xs text-[#554F47]">
                <a
                  href="tel:+15557892341"
                  className="flex items-center gap-1.5 hover:text-[#171614] font-medium"
                >
                  <Phone className="w-3.5 h-3.5 text-[#8C7355]" />
                  <span>+1 (555) 789-2341</span>
                </a>
                <a
                  href="mailto:concierge@maisonetoile-atelier.com"
                  className="flex items-center gap-1.5 hover:text-[#171614] font-medium"
                >
                  <Mail className="w-3.5 h-3.5 text-[#8C7355]" />
                  <span>concierge@maisonetoile-atelier.com</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Stylized Architectural Map & Directions */}
          <div className="lg:col-span-6 flex flex-col">
            <div className="bg-[#FAF8F3] border border-[#E6E1D8] rounded-2xl p-7 shadow-sm flex-1 flex flex-col justify-between">
              {/* Map Preview Graphic */}
              <div className="relative rounded-xl overflow-hidden aspect-[16/10] bg-[#EFECE6] border border-[#D9D2C5] shadow-inner flex items-center justify-center">
                {/* Stylized Architectural Street Map Background */}
                <div className="absolute inset-0 bg-[#E8E4DA] opacity-80" />
                
                {/* Visual streets */}
                <div className="absolute w-full h-8 bg-[#DFD9CE] top-1/3 -rotate-3" />
                <div className="absolute h-full w-10 bg-[#DFD9CE] left-1/2 rotate-6" />
                <div className="absolute w-full h-6 bg-[#DFD9CE] bottom-1/4 rotate-1" />

                {/* Pin Point */}
                <div className="relative z-10 flex flex-col items-center animate-bounce">
                  <div className="w-12 h-12 rounded-full bg-[#171614] border-2 border-[#C5A880] shadow-xl flex items-center justify-center text-[#C5A880]">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <div className="mt-2 bg-[#171614] text-white text-xs px-3 py-1 rounded-md shadow font-serif font-medium border border-[#C5A880]/40">
                    Maison Étoile Flagship
                  </div>
                </div>

                <div className="absolute bottom-3 left-3 bg-[#FDFBF7]/90 backdrop-blur px-3 py-1 rounded text-[11px] text-[#554F47] border border-[#D9D2C5]">
                  Promenade Court · 480 Haute Blvd
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <a
                  href="https://maps.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] active:scale-[0.98] transition-all rounded shadow-sm flex items-center justify-center gap-2"
                >
                  <Navigation className="w-3.5 h-3.5 text-[#C5A880]" />
                  <span>Get Driving Directions</span>
                </a>

                <a
                  href="https://wa.me/15557892341"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3 text-xs font-semibold uppercase tracking-wider text-[#171614] bg-[#F2EDE2] hover:bg-[#EAE4D7] border border-[#D9D2C5] rounded flex items-center justify-center gap-1.5"
                >
                  <span>WhatsApp Concierge</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
