import React from 'react';
import { Microscope, Sparkles, ShieldCheck, Heart, UserCheck, Droplets } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const points = [
    {
      icon: Microscope,
      title: 'Digital Scalp & Dermal Diagnostics',
      desc: 'We never guess. Every consultation utilizes high-magnification trichoscopy to analyze scalp follicular density, cuticle damage, and dermal lipid levels.'
    },
    {
      icon: Droplets,
      title: 'Tableside Bio-Formulation',
      desc: 'Color pigments and amino acid glazes are weighed and whipped tableside in front of you, custom-tailored to your exact hair porosity and undertone.'
    },
    {
      icon: ShieldCheck,
      title: 'Hospitality & Absolute Privacy',
      desc: 'Enjoy soundproof individual suites equipped with ergonomic Italian reclining wash lounges, acoustic comfort, high-speed WiFi, and champagne service.'
    },
    {
      icon: UserCheck,
      title: 'One-on-One Dedicated Attention',
      desc: 'Zero stylist double-booking or rushed hand-offs. Your master artisan attends exclusively to you for the entire duration of your reservation.'
    }
  ];

  return (
    <section className="bg-[#FDFBF7] py-20 border-b border-[#E6E1D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Editorial Philosophy */}
          <div className="lg:col-span-5 space-y-6 text-left">
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355]">
              The Maison Philosophy
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#171614] font-medium leading-tight text-balance">
              Redefining Haute Coiffure Beyond the Traditional Salon.
            </h2>
            <p className="text-sm sm:text-base text-[#554F47] leading-relaxed">
              We founded Maison Étoile on a simple realization: discerning clients do not merely seek a cut or facial; 
              they demand clinical precision, immaculate hygiene, and an atmosphere of uninterrupted calm.
            </p>
            <p className="text-sm text-[#70685D] leading-relaxed">
              From our zero-formaldehyde Nanoplastia to our patented HydraFacial MD protocols, every service is 
              formulated to deliver transformative aesthetic outcomes while protecting your biological wellness.
            </p>

            <div className="pt-2 flex items-center gap-6">
              <div>
                <span className="font-serif text-3xl font-semibold text-[#171614] tabular-nums block">
                  100%
                </span>
                <span className="text-xs text-[#70685D]">Single-Client Dedication</span>
              </div>
              <div className="h-8 w-px bg-[#E6E1D8]" />
              <div>
                <span className="font-serif text-3xl font-semibold text-[#171614] tabular-nums block">
                  0%
                </span>
                <span className="text-xs text-[#70685D]">Formaldehyde or Toxic Fumes</span>
              </div>
              <div className="h-8 w-px bg-[#E6E1D8]" />
              <div>
                <span className="font-serif text-3xl font-semibold text-[#171614] tabular-nums block">
                  4.9★
                </span>
                <span className="text-xs text-[#70685D]">Google Client Rating</span>
              </div>
            </div>
          </div>

          {/* Right Column: 4 Feature Blocks */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {points.map((pt, i) => {
              const Icon = pt.icon;
              return (
                <div
                  key={i}
                  className="bg-[#FAF8F3] p-6 rounded-xl border border-[#E6E1D8] hover:border-[#C5A880]/60 transition-colors shadow-sm"
                >
                  <div className="w-10 h-10 rounded-lg bg-[#F2EDE2] flex items-center justify-center text-[#8C7355] mb-4">
                    <Icon className="w-5 h-5 text-[#8C7355]" />
                  </div>
                  <h3 className="font-serif text-xl font-medium text-[#171614] mb-2">
                    {pt.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#665E53] leading-relaxed">
                    {pt.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
