import React, { useState } from 'react';
import { ArrowRight, Sparkles, Check, SlidersHorizontal } from 'lucide-react';

interface TransformationGalleryProps {
  onBookService: (serviceName: string) => void;
}

export const TransformationGallery: React.FC<TransformationGalleryProps> = ({ onBookService }) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [activeCaseIndex, setActiveCaseIndex] = useState(0);

  const cases = [
    {
      title: 'Organic Nanoplastia Glass Hair Transformation',
      subtitle: 'From frizzy, heat-damaged porosity to mirror-reflective liquid silk.',
      serviceName: 'Pure Organic Nanoplastia Glass Hair System',
      category: 'Nanoplastia Alchemy',
      duration: '3.5 Hours',
      artisan: 'Elena Rostova',
      hairProfile: 'Type 3B Coarse Texture · Bleach Over-processed',
      productsUsed: 'Hydrolyzed Silk Nano-Amino Matrix & Cold-Infused Argan Elixir',
      resultNotes: '100% frizz eradication with natural fluid swing. Expected durability: 5–6 months.',
      image: '/src/assets/images/salon_transformation_1791083583978.jpg'
    },
    {
      title: 'French Sun-Drenched Balayage & Root Melt',
      subtitle: 'Seamless dimensional contrast with zero line of demarcation.',
      serviceName: 'Maison Signature French Freehand Balayage',
      category: 'Haute Balayage',
      duration: '3 Hours',
      artisan: 'Julian de Laurent',
      hairProfile: 'Dark Brunette Base with fine highlights',
      productsUsed: 'Olaplex No. 1 Bond Multiplier & Organic Pearl Ash Toner',
      resultNotes: 'Soft ribbons of luminous champagne cream framed effortlessly around facial structure.',
      image: '/src/assets/images/salon_hair_styling_1791083559327.jpg'
    },
    {
      title: 'Hydra-Infusion MediGlow & Cellular Renewal',
      subtitle: 'Congested, hyperpigmented texture transformed to poreless dewy radiance.',
      serviceName: 'Hydra-Infusion MediGlow & Diamond Dermabrasion',
      category: 'Clinical Medifacial',
      duration: '75 Minutes',
      artisan: 'Dr. Clara Vance, MD',
      hairProfile: 'Fitzpatrick Type II · Dull, dehydrated dermal barrier',
      productsUsed: 'Salicylic Vortex Peel & Pure Botanical Hyaluronate Pods',
      resultNotes: 'Immediate glassy illumination with zero redness, downtime, or peeling.',
      image: '/src/assets/images/salon_skin_medifacial_1791083571953.jpg'
    }
  ];

  const current = cases[activeCaseIndex];

  return (
    <section id="transformations" className="bg-[#FDFBF7] py-20 border-b border-[#E6E1D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355] mb-2">
            <Sparkles className="w-3.5 h-3.5 text-[#C5A880]" />
            <span>Verifiable Results</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#171614] font-medium">
            The Atelier Transformation Gallery
          </h2>
          <p className="text-sm sm:text-base text-[#665E53] mt-3">
            Real clients, zero filters. Explore how our master formulations rebuild hair cuticle integrity and clinical skin health.
          </p>

          {/* Case Selector Tabs */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-2 p-1.5 bg-[#F2EDE2] rounded-xl border border-[#E0DBD0] max-w-xl mx-auto">
            {cases.map((c, i) => (
              <button
                key={i}
                onClick={() => {
                  setActiveCaseIndex(i);
                  setSliderPosition(50);
                }}
                className={`px-4 py-2 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                  activeCaseIndex === i
                    ? 'bg-[#171614] text-white shadow-sm'
                    : 'text-[#554F47] hover:text-[#171614]'
                }`}
              >
                {c.category}
              </button>
            ))}
          </div>
        </div>

        {/* Transformation Showcase Card */}
        <div className="bg-[#FAF8F3] border border-[#E6E1D8] rounded-2xl p-6 lg:p-10 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Interactive Split / Visual Area */}
          <div className="lg:col-span-7 flex flex-col space-y-4">
            <div className="relative rounded-xl overflow-hidden shadow-lg border border-[#E0DBD0] aspect-[16/10] bg-[#EFECE6] select-none">
              <img
                src={current.image}
                alt={current.title}
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />

              {/* Interactive Reveal Slider Overlay */}
              <div
                className="absolute inset-y-0 right-0 bg-[#2C2926]/40 backdrop-blur-[1.5px] border-l-2 border-[#C5A880] pointer-events-none transition-all"
                style={{ width: `${100 - sliderPosition}%` }}
              >
                <div className="absolute top-4 right-4 bg-black/60 text-white text-[11px] px-2.5 py-1 rounded backdrop-blur font-medium">
                  After Treatment
                </div>
              </div>

              <div
                className="absolute top-4 left-4 bg-black/60 text-white text-[11px] px-2.5 py-1 rounded backdrop-blur font-medium pointer-events-none"
              >
                Pre-Treatment Assessment
              </div>

              {/* Slider Control Handle */}
              <div
                className="absolute inset-y-0 flex items-center justify-center pointer-events-none"
                style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
              >
                <div className="w-8 h-8 rounded-full bg-[#171614] text-[#C5A880] border-2 border-white shadow-lg flex items-center justify-center">
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Hidden Range Input over image for drag */}
              <input
                type="range"
                min="0"
                max="100"
                value={sliderPosition}
                onChange={(e) => setSliderPosition(Number(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20"
                aria-label="Drag to compare before and after"
              />
            </div>

            <p className="text-center text-xs text-[#8C7355] flex items-center justify-center gap-1.5 font-medium">
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Slide horizontally across image to reveal post-ritual luminosity</span>
            </p>
          </div>

          {/* Details & Specifications Column */}
          <div className="lg:col-span-5 flex flex-col space-y-5 text-left">
            <div>
              <span className="text-xs font-semibold text-[#8C7355] uppercase tracking-wider">
                Case Study · {current.category}
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl font-medium text-[#171614] mt-1">
                {current.title}
              </h3>
              <p className="text-sm text-[#665E53] mt-2">
                {current.subtitle}
              </p>
            </div>

            <div className="space-y-3 pt-4 border-t border-[#E6E1D8] text-xs sm:text-sm">
              <div className="flex justify-between py-1 border-b border-[#EFECE6]">
                <span className="text-[#8C7355] font-medium">Lead Artisan</span>
                <span className="text-[#171614] font-semibold">{current.artisan}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#EFECE6]">
                <span className="text-[#8C7355] font-medium">Session Duration</span>
                <span className="text-[#171614] font-semibold tabular-nums">{current.duration}</span>
              </div>
              <div className="flex flex-col py-1 border-b border-[#EFECE6]">
                <span className="text-[#8C7355] font-medium mb-0.5">Hair / Skin Starting Baseline</span>
                <span className="text-[#171614]">{current.hairProfile}</span>
              </div>
              <div className="flex flex-col py-1 border-b border-[#EFECE6]">
                <span className="text-[#8C7355] font-medium mb-0.5">Bio-Active Formulations Used</span>
                <span className="text-[#171614]">{current.productsUsed}</span>
              </div>
            </div>

            <div className="bg-[#F2EDE2] p-4 rounded-xl border border-[#DFD8CC]">
              <div className="flex items-start gap-2 text-xs text-[#4A453E]">
                <Check className="w-4 h-4 text-[#8C7355] shrink-0 mt-0.5" />
                <span>{current.resultNotes}</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => onBookService(current.serviceName)}
                className="w-full py-3.5 px-6 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] active:scale-[0.99] transition-all rounded shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Book This Exact Transformation</span>
                <ArrowRight className="w-4 h-4 text-[#C5A880]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
