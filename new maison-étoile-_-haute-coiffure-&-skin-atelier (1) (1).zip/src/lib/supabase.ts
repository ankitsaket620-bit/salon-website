/**
 * Supabase Client Configuration & Adapter
 * Automatically connects to your Supabase project when VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are provided.
 * Gracefully integrates with the reactive SalonStorage engine so the application works out-of-the-box.
 */

export const SUPABASE_CONFIG = {
  url: import.meta.env.VITE_SUPABASE_URL || '',
  anonKey: import.meta.env.VITE_SUPABASE_ANON_KEY || '',
  isConfigured: Boolean(import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY)
};

export const getSupabaseClientInfo = () => {
  return {
    isConfigured: SUPABASE_CONFIG.isConfigured,
    url: SUPABASE_CONFIG.url ? `${SUPABASE_CONFIG.url.slice(0, 20)}...` : 'Not connected (running local storage mode)',
    mode: SUPABASE_CONFIG.isConfigured ? 'Direct Supabase Cloud' : 'High-Performance Local Persistence'
  };
};
