/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TrustCredibility } from './components/TrustCredibility';
import { TransformationGallery } from './components/TransformationGallery';
import { ServicesDirectory } from './components/ServicesDirectory';
import { PackagesOffers } from './components/PackagesOffers';
import { WhyChooseUs } from './components/WhyChooseUs';
import { TeamSection } from './components/TeamSection';
import { Testimonials } from './components/Testimonials';
import { LookbookInstagram } from './components/LookbookInstagram';
import { LocationHours } from './components/LocationHours';
import { ContactSection } from './components/ContactSection';
import { FinalBookingCta } from './components/FinalBookingCta';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { CustomerAccountModal } from './components/CustomerAccountModal';
import { AdminDashboard } from './components/AdminDashboard';
import { FloatingContactWidget } from './components/FloatingContactWidget';
import { ContactModal } from './components/ContactModal';
import { SalonStorage } from './lib/storage';
import { Service, Staff, SpecialOffer, Review, Appointment, UserProfile } from './types';

export default function App() {
  // Global State from Storage
  const [services, setServices] = useState<Service[]>([]);
  const [staff, setStaff] = useState<Staff[]>([]);
  const [offers, setOffers] = useState<SpecialOffer[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);

  // Modal Visibility State
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [contactModalOpen, setContactModalOpen] = useState(false);

  // Pre-selection params for booking
  const [preSelectedServiceId, setPreSelectedServiceId] = useState<string | null>(null);
  const [preSelectedStaffId, setPreSelectedStaffId] = useState<string | null>(null);

  // Success toast notice
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const loadData = () => {
    setServices(SalonStorage.getServices());
    setStaff(SalonStorage.getStaff());
    setOffers(SalonStorage.getOffers());
    setReviews(SalonStorage.getReviews());
    setCurrentUser(SalonStorage.getCurrentUser());
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenBookingWithService = (serviceIdOrName: string) => {
    setPreSelectedServiceId(serviceIdOrName);
    setPreSelectedStaffId(null);
    setBookingModalOpen(true);
  };

  const handleOpenBookingWithStaff = (staffId: string) => {
    setPreSelectedStaffId(staffId);
    setPreSelectedServiceId(null);
    setBookingModalOpen(true);
  };

  const handleBookingComplete = (apt: Appointment) => {
    loadData();
    setToastMessage(`Reservation ${apt.bookingReference} confirmed for ${apt.customerName}`);
    setTimeout(() => setToastMessage(null), 5000);
  };

  const handleAddReview = (newRev: Omit<Review, 'id' | 'verified'>) => {
    SalonStorage.addReview(newRev);
    loadData();
    setToastMessage('Thank you. Your review has been added to our verified client ledger.');
    setTimeout(() => setToastMessage(null), 4000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FDFBF7] text-[#171614]">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#171614] text-white px-5 py-3 rounded-xl shadow-2xl border border-[#C5A880]/50 text-xs font-medium flex items-center gap-3 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{toastMessage}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="text-[#A89F91] hover:text-white text-xs ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {/* 1. Luxury Navbar */}
      <Navbar
        onOpenBooking={() => {
          setPreSelectedServiceId(null);
          setPreSelectedStaffId(null);
          setBookingModalOpen(true);
        }}
        onOpenAccount={() => setAccountModalOpen(true)}
        onOpenAdmin={() => setAdminModalOpen(true)}
        onOpenContact={() => setContactModalOpen(true)}
        currentUser={currentUser}
      />

      {/* 2. Hero Section */}
      <Hero
        onOpenBooking={() => {
          setPreSelectedServiceId(null);
          setPreSelectedStaffId(null);
          setBookingModalOpen(true);
        }}
        onExploreServices={() => {
          const el = document.getElementById('services');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* 3. Trust & Credibility */}
      <TrustCredibility />

      {/* 4. Before & After Transformation Gallery */}
      <TransformationGallery
        onBookService={(serviceName) => handleOpenBookingWithService(serviceName)}
      />

      {/* 5. Complete Services Directory & Filterable Categories */}
      <ServicesDirectory
        services={services}
        onBookService={(serviceId) => handleOpenBookingWithService(serviceId)}
      />

      {/* 6. Curated Packages & Seasonal Offers */}
      <PackagesOffers
        offers={offers}
        onBookPackage={(packageTitle) => handleOpenBookingWithService(packageTitle)}
      />

      {/* 7. Why Choose Us */}
      <WhyChooseUs />

      {/* 8. Master Team Section */}
      <TeamSection
        staff={staff}
        onBookWithStaff={(staffId) => handleOpenBookingWithStaff(staffId)}
      />

      {/* 9. Verified Customer Testimonials */}
      <Testimonials
        reviews={reviews}
        onAddReview={handleAddReview}
      />

      {/* 10. Social Lookbook */}
      <LookbookInstagram />

      {/* 11. Location, Opening Hours & Valet */}
      <LocationHours />

      {/* 12. Concierge Inquiries */}
      <ContactSection />

      {/* 13. Final Booking CTA Banner */}
      <FinalBookingCta
        onOpenBooking={() => {
          setPreSelectedServiceId(null);
          setPreSelectedStaffId(null);
          setBookingModalOpen(true);
        }}
      />

      {/* 14. Luxury Footer */}
      <Footer
        onOpenBooking={() => {
          setPreSelectedServiceId(null);
          setPreSelectedStaffId(null);
          setBookingModalOpen(true);
        }}
        onOpenAccount={() => setAccountModalOpen(true)}
        onOpenAdmin={() => setAdminModalOpen(true)}
      />

      {/* Modals */}
      <BookingModal
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        preSelectedServiceId={preSelectedServiceId}
        preSelectedStaffId={preSelectedStaffId}
        currentUser={currentUser}
        onBookingComplete={handleBookingComplete}
      />

      <CustomerAccountModal
        isOpen={accountModalOpen}
        onClose={() => setAccountModalOpen(false)}
        currentUser={currentUser}
        onUserChange={(usr) => setCurrentUser(usr)}
        onOpenBooking={() => {
          setAccountModalOpen(false);
          setBookingModalOpen(true);
        }}
      />

      <AdminDashboard
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        onDataChanged={loadData}
      />

      {/* Dedicated Contact & Concierge Modal */}
      <ContactModal
        isOpen={contactModalOpen}
        onClose={() => setContactModalOpen(false)}
      />

      {/* Floating 1-Tap Contact Action Widget */}
      <FloatingContactWidget
        onOpenContactModal={() => setContactModalOpen(true)}
      />
    </div>
  );
}
