import React, { useState, useEffect } from 'react';
import { X, User, Calendar, Clock, RotateCcw, AlertTriangle, CheckCircle, LogOut, Lock, Mail, Phone, Shield } from 'lucide-react';
import { Appointment, UserProfile } from '../types';
import { SalonStorage } from '../lib/storage';

interface CustomerAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  onUserChange: (user: UserProfile | null) => void;
  onOpenBooking: () => void;
}

export const CustomerAccountModal: React.FC<CustomerAccountModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUserChange,
  onOpenBooking
}) => {
  const [activeTab, setActiveTab] = useState<'appointments' | 'profile' | 'auth'>('appointments');
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'forgot'>('login');

  // Auth Inputs
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [authPhone, setAuthPhone] = useState('');
  const [authMessage, setAuthMessage] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  // Appointments
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [reschedulingId, setReschedulingId] = useState<string | null>(null);
  const [newRescheduleDate, setNewRescheduleDate] = useState('');
  const [newRescheduleTime, setNewRescheduleTime] = useState('');
  const [rescheduleSlots, setRescheduleSlots] = useState<{ time: string; available: boolean }[]>([]);
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState('Change in schedule');

  // Load appointments
  const refreshAppointments = () => {
    const all = SalonStorage.getAppointments();
    if (currentUser) {
      // Filter by current user email or name
      const userApts = all.filter(
        (a) => a.customerEmail.toLowerCase() === currentUser.email.toLowerCase() || a.userId === currentUser.id
      );
      setAppointments(userApts.length > 0 ? userApts : all);
    } else {
      setAppointments(all);
    }
  };

  useEffect(() => {
    if (isOpen) {
      refreshAppointments();
      if (!currentUser) {
        setActiveTab('auth');
      } else {
        setActiveTab('appointments');
      }
      setAuthMessage(null);
      setReschedulingId(null);
      setCancellingId(null);
    }
  }, [isOpen, currentUser]);

  // Update reschedule slots
  useEffect(() => {
    if (reschedulingId && newRescheduleDate) {
      const apt = appointments.find((a) => a.id === reschedulingId);
      if (apt) {
        const slots = SalonStorage.getAvailableSlots(apt.staffId, newRescheduleDate, apt.id);
        setRescheduleSlots(slots);
      }
    }
  }, [reschedulingId, newRescheduleDate, appointments]);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authEmail.trim()) {
      setAuthMessage({ type: 'error', text: 'Please provide a valid email.' });
      return;
    }
    const user: UserProfile = {
      id: `usr-${Date.now()}`,
      email: authEmail.trim(),
      fullName: authName.trim() || 'Valued Guest',
      phone: authPhone.trim() || '+1 (555) 789-2341',
      role: 'customer',
      createdAt: new Date().toISOString()
    };
    SalonStorage.setCurrentUser(user);
    onUserChange(user);
    setActiveTab('appointments');
    setAuthMessage({ type: 'success', text: 'Welcome back to Maison Étoile.' });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authEmail.trim() || !authName.trim()) {
      setAuthMessage({ type: 'error', text: 'Please fill in all required fields.' });
      return;
    }
    const user: UserProfile = {
      id: `usr-${Date.now()}`,
      email: authEmail.trim(),
      fullName: authName.trim(),
      phone: authPhone.trim(),
      role: 'customer',
      createdAt: new Date().toISOString()
    };
    SalonStorage.setCurrentUser(user);
    onUserChange(user);
    setActiveTab('appointments');
    setAuthMessage({ type: 'success', text: 'Your atelier account has been created.' });
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthMessage({
      type: 'success',
      text: `Password reset instructions dispatched to ${authEmail}. Please check your inbox.`
    });
  };

  const handleLogout = () => {
    SalonStorage.setCurrentUser(null);
    onUserChange(null);
    setActiveTab('auth');
    setAuthMode('login');
  };

  const handleCancelAppointment = (id: string) => {
    SalonStorage.cancelAppointment(id, cancelReason);
    setCancellingId(null);
    refreshAppointments();
  };

  const handleSaveReschedule = (id: string) => {
    if (!newRescheduleDate || !newRescheduleTime) return;
    const res = SalonStorage.rescheduleAppointment(id, newRescheduleDate, newRescheduleTime);
    if (res.success) {
      setReschedulingId(null);
      refreshAppointments();
    } else {
      alert(res.error || 'Failed to reschedule.');
    }
  };

  const upcomingApts = appointments.filter((a) => a.status === 'confirmed' || a.status === 'in-progress');
  const pastApts = appointments.filter((a) => a.status === 'completed' || a.status === 'cancelled');

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-[#FDFBF7] border border-[#D9D2C5] rounded-2xl max-w-2xl w-full my-8 shadow-2xl overflow-hidden flex flex-col relative animate-in fade-in zoom-in-95 duration-150 text-left">
        {/* Header */}
        <div className="px-6 py-4 bg-[#FAF8F3] border-b border-[#E6E1D8] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#171614] text-[#C5A880] flex items-center justify-center font-serif text-lg font-medium">
              {currentUser ? currentUser.fullName.slice(0, 2).toUpperCase() : <User className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="font-serif text-xl sm:text-2xl font-medium text-[#171614]">
                {currentUser ? currentUser.fullName : 'Guest Portal'}
              </h2>
              <span className="text-xs text-[#8C7355]">
                {currentUser ? currentUser.email : 'Sign in to manage appointments & preferences'}
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#8C7355] hover:text-[#171614] hover:bg-[#F2EDE2] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        {currentUser && (
          <div className="px-6 bg-[#F5F2EB] border-b border-[#E6E1D8] flex items-center justify-between text-xs font-medium">
            <div className="flex gap-4">
              <button
                onClick={() => setActiveTab('appointments')}
                className={`py-3 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'appointments'
                    ? 'border-[#171614] text-[#171614] font-semibold'
                    : 'border-transparent text-[#70685D] hover:text-[#171614]'
                }`}
              >
                My Reservations ({upcomingApts.length})
              </button>
              <button
                onClick={() => setActiveTab('profile')}
                className={`py-3 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'profile'
                    ? 'border-[#171614] text-[#171614] font-semibold'
                    : 'border-transparent text-[#70685D] hover:text-[#171614]'
                }`}
              >
                Client Profile & Notes
              </button>
            </div>

            <button
              onClick={handleLogout}
              className="text-xs text-rose-700 hover:text-rose-900 flex items-center gap-1 font-medium"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        )}

        {/* Body Content */}
        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {/* TAB: AUTH (Login / Register / Forgot Password) */}
          {activeTab === 'auth' && (
            <div className="max-w-md mx-auto py-2">
              <div className="text-center mb-6">
                <span className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355]">
                  Maison Étoile Privé
                </span>
                <h3 className="font-serif text-2xl font-medium text-[#171614] mt-1">
                  {authMode === 'login' && 'Sign In to Your Account'}
                  {authMode === 'register' && 'Create Your Atelier Profile'}
                  {authMode === 'forgot' && 'Reset Confidential Password'}
                </h3>
                <p className="text-xs text-[#70685D] mt-1">
                  Access upcoming appointments, private history, and custom scalp notes.
                </p>
              </div>

              {authMessage && (
                <div
                  className={`mb-4 p-3 rounded-lg text-xs flex items-center gap-2 ${
                    authMessage.type === 'error'
                      ? 'bg-rose-50 border border-rose-200 text-rose-800'
                      : 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                  }`}
                >
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  <span>{authMessage.text}</span>
                </div>
              )}

              {/* Login Form */}
              {authMode === 'login' && (
                <form onSubmit={handleLogin} className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. sophie.vdb@example.com"
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Password
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div className="flex justify-between items-center text-xs">
                    <button
                      type="button"
                      onClick={() => setAuthMode('forgot')}
                      className="text-[#8C7355] hover:underline"
                    >
                      Forgot password?
                    </button>
                    <button
                      type="button"
                      onClick={() => setAuthMode('register')}
                      className="text-[#171614] font-medium hover:underline"
                    >
                      New client? Register
                    </button>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] rounded shadow transition-all cursor-pointer"
                  >
                    Enter Private Sanctuary
                  </button>
                </form>
              )}

              {/* Register Form */}
              {authMode === 'register' && (
                <form onSubmit={handleRegister} className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Sophie Van Der Bilt"
                      value={authName}
                      onChange={(e) => setAuthName(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. sophie.vdb@example.com"
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Mobile Telephone *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. +1 (555) 349-1120"
                      value={authPhone}
                      onChange={(e) => setAuthPhone(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Password *
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div className="flex justify-between items-center text-xs">
                    <button
                      type="button"
                      onClick={() => setAuthMode('login')}
                      className="text-[#171614] font-medium hover:underline"
                    >
                      Already registered? Sign In
                    </button>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] rounded shadow transition-all cursor-pointer"
                  >
                    Create Profile & Begin
                  </button>
                </form>
              )}

              {/* Forgot Password Form */}
              {authMode === 'forgot' && (
                <form onSubmit={handleForgotPassword} className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-[#8C7355] block mb-1">
                      Account Email Address
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. sophie.vdb@example.com"
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-[#D9D2C5] rounded-lg focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] rounded shadow transition-all"
                  >
                    Send Recovery Link
                  </button>

                  <div className="text-center pt-2">
                    <button
                      type="button"
                      onClick={() => setAuthMode('login')}
                      className="text-xs text-[#8C7355] hover:underline"
                    >
                      Back to Sign In
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* TAB: APPOINTMENTS */}
          {activeTab === 'appointments' && (
            <div className="space-y-6">
              {/* Upcoming Reservations */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-serif text-lg font-medium text-[#171614]">
                    Upcoming Reservations
                  </h3>
                  <button
                    onClick={() => {
                      onClose();
                      onOpenBooking();
                    }}
                    className="text-xs font-semibold text-[#8C7355] hover:text-[#171614] flex items-center gap-1"
                  >
                    + Book New Service
                  </button>
                </div>

                {upcomingApts.length === 0 ? (
                  <div className="bg-[#FAF8F3] p-8 rounded-xl border border-dashed border-[#D9D2C5] text-center text-[#70685D]">
                    <p className="text-sm font-medium text-[#171614]">No upcoming appointments scheduled.</p>
                    <p className="text-xs mt-1">Experience our bespoke hair and skin therapies at your convenience.</p>
                    <button
                      onClick={() => {
                        onClose();
                        onOpenBooking();
                      }}
                      className="mt-3 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] rounded"
                    >
                      Reserve Appointment
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {upcomingApts.map((apt) => (
                      <div
                        key={apt.id}
                        className="bg-[#FAF8F3] rounded-xl border border-[#E6E1D8] p-5 shadow-sm space-y-3"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#EFECE6]">
                          <div>
                            <span className="font-mono text-xs font-bold text-[#8C7355] block">
                              Ref: {apt.bookingReference}
                            </span>
                            <h4 className="font-serif text-lg font-medium text-[#171614]">
                              {apt.serviceName}
                            </h4>
                          </div>

                          <div className="flex items-center gap-2">
                            <span
                              className={`text-[11px] px-2.5 py-0.5 rounded font-medium ${
                                apt.status === 'in-progress'
                                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                  : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                              }`}
                            >
                              {apt.status === 'in-progress' ? 'In Progress' : 'Confirmed'}
                            </span>
                            <span className="font-serif font-bold text-base text-[#171614] tabular-nums">
                              ${apt.totalPrice}
                            </span>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-[#554F47]">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-[#8C7355]" />
                            <span className="tabular-nums font-medium">{apt.appointmentDate}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-[#8C7355]" />
                            <span className="tabular-nums font-medium">{apt.appointmentTime}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <User className="w-3.5 h-3.5 text-[#8C7355]" />
                            <span>{apt.staffName}</span>
                          </div>
                        </div>

                        {apt.notes && (
                          <p className="text-xs text-[#70685D] italic bg-[#F2EDE2] p-2 rounded">
                            "{apt.notes}"
                          </p>
                        )}

                        {/* Action buttons (Reschedule / Cancel) */}
                        <div className="pt-2 flex items-center justify-end gap-2 border-t border-[#EFECE6]">
                          <button
                            onClick={() => {
                              setReschedulingId(apt.id);
                              setNewRescheduleDate(apt.appointmentDate);
                              setNewRescheduleTime(apt.appointmentTime);
                            }}
                            className="px-3 py-1.5 text-xs font-medium text-[#171614] hover:bg-[#F2EDE2] border border-[#D9D2C5] rounded flex items-center gap-1"
                          >
                            <RotateCcw className="w-3 h-3 text-[#8C7355]" />
                            <span>Reschedule</span>
                          </button>

                          <button
                            onClick={() => setCancellingId(apt.id)}
                            className="px-3 py-1.5 text-xs font-medium text-rose-700 hover:bg-rose-50 border border-rose-200 rounded"
                          >
                            Cancel
                          </button>
                        </div>

                        {/* Inline Reschedule Widget */}
                        {reschedulingId === apt.id && (
                          <div className="mt-3 p-4 bg-[#F2EDE2] rounded-xl border border-[#D9D2C5] space-y-3">
                            <div className="flex justify-between items-center text-xs font-semibold text-[#171614]">
                              <span>Select New Date & Slot</span>
                              <button
                                onClick={() => setReschedulingId(null)}
                                className="text-xs text-[#70685D] hover:text-[#171614]"
                              >
                                Close
                              </button>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                              <div>
                                <label className="block mb-1 text-[#8C7355]">New Date</label>
                                <input
                                  type="date"
                                  value={newRescheduleDate}
                                  onChange={(e) => setNewRescheduleDate(e.target.value)}
                                  className="w-full px-2.5 py-1.5 bg-white border border-[#D9D2C5] rounded"
                                />
                              </div>

                              <div>
                                <label className="block mb-1 text-[#8C7355]">Available Time</label>
                                <select
                                  value={newRescheduleTime}
                                  onChange={(e) => setNewRescheduleTime(e.target.value)}
                                  className="w-full px-2.5 py-1.5 bg-white border border-[#D9D2C5] rounded"
                                >
                                  {rescheduleSlots.map((s) => (
                                    <option key={s.time} value={s.time} disabled={!s.available}>
                                      {s.time} {s.available ? '' : '(Booked)'}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>

                            <button
                              onClick={() => handleSaveReschedule(apt.id)}
                              className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] rounded hover:bg-[#2C2926]"
                            >
                              Confirm Reschedule
                            </button>
                          </div>
                        )}

                        {/* Inline Cancel Reason Widget */}
                        {cancellingId === apt.id && (
                          <div className="mt-3 p-4 bg-rose-50 rounded-xl border border-rose-200 space-y-3 text-xs text-rose-900">
                            <div className="flex items-center gap-1.5 font-semibold">
                              <AlertTriangle className="w-4 h-4 text-rose-600" />
                              <span>Confirm Appointment Cancellation</span>
                            </div>
                            <p className="text-[11px] text-rose-800">
                              Please review our 24-hour courtesy policy. Would you like to provide a reason for the artisan?
                            </p>
                            <input
                              type="text"
                              value={cancelReason}
                              onChange={(e) => setCancelReason(e.target.value)}
                              placeholder="e.g. Flight delay / Personal conflict"
                              className="w-full px-3 py-1.5 bg-white border border-rose-300 rounded text-xs"
                            />
                            <div className="flex gap-2 justify-end">
                              <button
                                onClick={() => setCancellingId(null)}
                                className="px-3 py-1 text-xs text-rose-900 font-medium"
                              >
                                Keep Appointment
                              </button>
                              <button
                                onClick={() => handleCancelAppointment(apt.id)}
                                className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-700 rounded hover:bg-rose-800"
                              >
                                Confirm Cancel
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Past History */}
              {pastApts.length > 0 && (
                <div className="pt-4 border-t border-[#E6E1D8]">
                  <h3 className="font-serif text-lg font-medium text-[#171614] mb-3">
                    Appointment History & Invoices
                  </h3>
                  <div className="space-y-2">
                    {pastApts.map((past) => (
                      <div
                        key={past.id}
                        className="bg-white p-3.5 rounded-lg border border-[#E6E1D8] flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-medium text-[#171614]">{past.serviceName}</span>
                          <span className="text-[#8C7355] block">
                            {past.appointmentDate} with {past.staffName}
                          </span>
                        </div>
                        <div className="text-right">
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded font-medium ${
                              past.status === 'completed'
                                ? 'bg-slate-100 text-slate-700'
                                : 'bg-rose-50 text-rose-700'
                            }`}
                          >
                            {past.status === 'completed' ? 'Completed' : 'Cancelled'}
                          </span>
                          <span className="block font-semibold text-[#171614] tabular-nums mt-0.5">
                            ${past.totalPrice}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB: PROFILE */}
          {activeTab === 'profile' && currentUser && (
            <div className="space-y-4">
              <div className="bg-[#FAF8F3] p-5 rounded-xl border border-[#E6E1D8] space-y-3 text-xs sm:text-sm">
                <div className="flex justify-between py-1 border-b border-[#EFECE6]">
                  <span className="text-[#8C7355]">Full Name:</span>
                  <span className="font-semibold text-[#171614]">{currentUser.fullName}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#EFECE6]">
                  <span className="text-[#8C7355]">Account Email:</span>
                  <span className="font-semibold text-[#171614]">{currentUser.email}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#EFECE6]">
                  <span className="text-[#8C7355]">Telephone:</span>
                  <span className="font-semibold text-[#171614]">{currentUser.phone || 'Not specified'}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-[#8C7355]">Sanctuary Tier:</span>
                  <span className="font-serif font-semibold text-[#171614]">Private Atelier VIP Member</span>
                </div>
              </div>

              <div className="p-4 bg-[#F2EDE2] rounded-xl border border-[#DFD9CE] text-xs">
                <span className="font-semibold text-[#171614] block mb-1">Trichological Profile & Preference Record</span>
                <p className="text-[#665E53] leading-relaxed">
                  Your preference notes and hair chemistry history are stored in your encrypted profile for tableside color formulation and product selection.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
