import React from 'react';
import { Award, Sparkles, ShieldCheck, HeartHandshake, Coffee, CheckCircle2 } from 'lucide-react';

export const TrustCredibility: React.FC = () => {
  const pillars = [
    {
      icon: Award,
      title: 'International Master Artistry',
      desc: 'Our lead stylists and colorists are Vidal Sassoon Academy alumni with Paris & Milan runway credentials.'
    },
    {
      icon: ShieldCheck,
      title: 'Medical-Grade Sterilization',
      desc: 'All instruments undergo autoclave medical-grade thermal sterilization. Single-use organic linen only.'
    },
    {
      icon: Sparkles,
      title: 'Bio-Clean Dermal Formulations',
      desc: 'Strictly zero formaldehyde, zero ammonia, and zero sulfates. Only certified bioactive organic compounds.'
    },
    {
      icon: Coffee,
      title: 'Private Suites & Bespoke Bar',
      desc: 'Private soundproof treatment rooms accompanied by single-origin pour-overs, organic matcha, and champagne.'
    }
  ];

  return (
    <section className="bg-[#F8F5EE] py-14 border-b border-[#E6E1D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Editorial Subheader */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-6 border-b border-[#E2DDD3]">
          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355]">
              The Maison Standard
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl text-[#171614] font-medium mt-1">
              Uncompromising Luxury. Verifiable Excellence.
            </h2>
          </div>
          <p className="text-sm text-[#70685D] max-w-md mt-2 md:mt-0">
            Every ritual is conducted under strict trichological and dermal protocols, 
            ensuring your safety, comfort, and breathtaking aesthetic results.
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {pillars.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="bg-[#FDFBF7] p-6 rounded-xl border border-[#E6E1D8] shadow-sm hover:border-[#C5A880]/50 transition-colors"
              >
                <div className="w-10 h-10 rounded-lg bg-[#F5F1E8] flex items-center justify-center text-[#8C7355] mb-4">
                  <Icon className="w-5 h-5 text-[#8C7355]" />
                </div>
                <h3 className="font-serif text-lg font-medium text-[#171614] mb-2">
                  {item.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#665E53] leading-relaxed">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>

        {/* Brand Accolades Bar */}
        <div className="mt-10 pt-6 border-t border-[#E2DDD3] flex flex-wrap items-center justify-center md:justify-between gap-6 text-xs text-[#8C7355] font-medium uppercase tracking-widest">
          <span className="flex items-center gap-1.5 text-[#554F47]">
            <CheckCircle2 className="w-4 h-4 text-[#8C7355]" /> Kérastase Paris Official Flagship
          </span>
          <span className="flex items-center gap-1.5 text-[#554F47]">
            <CheckCircle2 className="w-4 h-4 text-[#8C7355]" /> Dyson Supersonic Pro Ambassador
          </span>
          <span className="flex items-center gap-1.5 text-[#554F47]">
            <CheckCircle2 className="w-4 h-4 text-[#8C7355]" /> Olaplex Certified Master Colorist
          </span>
          <span className="flex items-center gap-1.5 text-[#554F47]">
            <CheckCircle2 className="w-4 h-4 text-[#8C7355]" /> HydraFacial MD Elite Provider
          </span>
        </div>
      </div>
    </section>
  );
};
