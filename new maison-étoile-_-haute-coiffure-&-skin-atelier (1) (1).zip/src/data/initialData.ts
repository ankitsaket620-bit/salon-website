import { Service, Staff, SpecialOffer, Review, Appointment } from '../types';

export const INITIAL_SERVICES: Service[] = [
  // Haircut
  {
    id: 'srv-1',
    name: 'Bespoke Haute Haircut & Blow-dry',
    category: 'Haircut',
    description: 'Precision architectural cut tailored to facial structure, bone line, and natural texture. Includes scalp diagnosis and thermal blowout.',
    price: 85,
    durationMinutes: 60,
    suitableFor: 'All hair lengths & textures seeking structural silhouette and easy home maintenance',
    isActive: true,
    featured: true,
    benefits: ['Scalp diagnostics', 'Custom texture shaping', 'Signature silk finish']
  },
  {
    id: 'srv-2',
    name: 'French Bob & Deconstructive Fringe',
    category: 'Haircut',
    description: 'Effortless Parisian blunt cut or layered textured bob paired with bespoke curtain bangs or wispy micro-fringe.',
    price: 95,
    durationMinutes: 75,
    suitableFor: 'Fine to medium hair desiring contemporary movement and chic editorial lift',
    isActive: true,
    featured: false,
    benefits: ['Precision edge graduation', 'Texturizing shear technique', 'Root volume boost']
  },

  // Hair Wash
  {
    id: 'srv-3',
    name: 'Kérastase Caviar Hair & Scalp Detox Wash',
    category: 'Hair Wash',
    description: 'Deep revitalizing scalp cleanse utilizing Kérastase Chronologiste caviar beads, gentle exfoliating clay, and jade comb lymphatic drainage.',
    price: 45,
    durationMinutes: 40,
    suitableFor: 'Dry, congested, or stressed scalps in need of deep rejuvenation',
    isActive: true,
    featured: false,
    benefits: ['Scalp circulation boost', 'Impurities elimination', 'Silky root-to-tip shine']
  },

  // Hair Styling
  {
    id: 'srv-4',
    name: 'Red Carpet Glam Waves & Thermal Finish',
    category: 'Hair Styling',
    description: 'Iconic Old Hollywood waves, textured voluminous ripples, or mirror-sheen glass sleekness set with high-hold anti-humidity mist.',
    price: 70,
    durationMinutes: 50,
    suitableFor: 'Special occasions, red-carpet galas, portrait shoots, or evening soirées',
    isActive: true,
    featured: true,
    benefits: ['48-hour humidity resistance', 'High-gloss thermal seal', 'Weightless bounce']
  },

  // Hair Colour
  {
    id: 'srv-5',
    name: 'Organic Ammonia-Free Global Glaze & Tone',
    category: 'Hair Colour',
    description: 'Enriched with botanical oils and liquid silk proteins, delivering multi-dimensional chromatic depth without structural damage.',
    price: 130,
    durationMinutes: 90,
    suitableFor: 'Clients wanting rich monochromatic tone, gray blending, or reflective gloss',
    isActive: true,
    featured: false,
    benefits: ['Zero ammonia odor', 'Reflective mirror sheen', 'Moisture locking matrix']
  },

  // Highlights
  {
    id: 'srv-6',
    name: 'Dimensional Foil Babylights & Root Smudge',
    category: 'Highlights',
    description: 'Ultra-fine micro-weaving across the crown and hairline for seamless sun-kissed illumination with soft grow-out diffusion.',
    price: 195,
    durationMinutes: 150,
    suitableFor: 'Those desiring luminous natural brightness with minimal line of demarcation',
    isActive: true,
    featured: false,
    benefits: ['Micro-fine foil placement', 'Custom shadow root', 'Olaplex bond protector']
  },

  // Balayage/Ombre
  {
    id: 'srv-7',
    name: 'Maison Signature French Freehand Balayage',
    category: 'Balayage/Ombre',
    description: 'Custom hand-painted gradients graduating from natural roots to luminous golden or smoky ash ribbons. Includes personalized gloss glaze.',
    price: 240,
    durationMinutes: 180,
    suitableFor: 'Low-maintenance luxury lovers wanting multidimensional natural depth',
    isActive: true,
    featured: true,
    benefits: ['Freehand artistic placement', 'Subtle grow-out transition', 'Gloss toner seal included']
  },

  // Hair Treatment
  {
    id: 'srv-8',
    name: 'Olaplex No. 1 & 2 Molecular Bond Rescue',
    category: 'Hair Treatment',
    description: 'Patented bis-aminopropyl diglycol dimaleate formulation that permanently repairs broken disulfide bonds caused by chemical or heat styling.',
    price: 65,
    durationMinutes: 45,
    suitableFor: 'Bleached, brittle, over-processed, or high-porosity strands',
    isActive: true,
    featured: false,
    benefits: ['Structural disulfide rebuild', 'Elasticity restoration', 'Split end cohesion']
  },

  // Hair Straightening
  {
    id: 'srv-9',
    name: 'Japanese Ionic Thermal Reconditioning',
    category: 'Hair Straightening',
    description: 'Permanent structural straightening utilizing negative ion infusion to transform unruly curls into pin-straight, ultra-glossy liquid glass.',
    price: 280,
    durationMinutes: 210,
    suitableFor: 'Coarse, thick, frizzy, or resistant curly hair wanting permanent sleekness',
    isActive: true,
    featured: false,
    benefits: ['Pin-straight sleekness', 'Rain & humidity proof', 'Long-lasting structural change']
  },

  // Rebonding
  {
    id: 'srv-10',
    name: 'Silk Protein Keratin Rebonding',
    category: 'Rebonding',
    description: 'Softened restructuring formula enriched with hydrolyzed silk and argan oil for straight, manageable hair with natural fluidity and swing.',
    price: 260,
    durationMinutes: 195,
    suitableFor: 'Unmanageable waves and curls seeking smooth texture with supple flexibility',
    isActive: true,
    featured: false,
    benefits: ['Supple natural swing', 'Zero chemical crunch', '6+ months manageable smoothness']
  },

  // Nanoplastia
  {
    id: 'srv-11',
    name: 'Pure Organic Nanoplastia Glass Hair System',
    category: 'Nanoplastia',
    description: '100% formaldehyde-free amino acid nano-technology. Penetrates deep into the hair cortex to restore, straighten, and deposit mirror glass reflection.',
    price: 310,
    durationMinutes: 210,
    suitableFor: 'Anyone seeking flawless frizz eradication and mirror-like glass reflection safely',
    isActive: true,
    featured: true,
    benefits: ['Zero harmful fumes or formaldehyde', 'Lasts up to 6 months', 'Extreme mirror reflection']
  },

  // Facial
  {
    id: 'srv-12',
    name: 'Cellular Vitality Oxygen Glow Facial',
    category: 'Facial',
    description: 'Hyperbaric oxygen mist infused with botanical hyaluronic serum, followed by cryo-sculpting globes and vitamin peptide infusion.',
    price: 110,
    durationMinutes: 60,
    suitableFor: 'Dehydrated, tired, jet-lagged, or dull skin needing instant plumping',
    isActive: true,
    featured: false,
    benefits: ['Instant dewy glow', 'Pore refinement', 'Puffiness relief via cryo-sculpting']
  },

  // Medifacial
  {
    id: 'srv-13',
    name: 'Hydra-Infusion MediGlow & Diamond Dermabrasion',
    category: 'Medifacial',
    description: 'Medical-grade 4-step hydra vortex suction: deep mechanical exfoliation, salicylic peel, vortex extraction, and antioxidant peptide saturation with LED therapy.',
    price: 165,
    durationMinutes: 75,
    suitableFor: 'Congested pores, hyperpigmentation, uneven skin texture, and fine lines',
    isActive: true,
    featured: true,
    benefits: ['Vortex deep pore extraction', 'Medical-grade LED phototherapy', 'Zero downtime radiance']
  },

  // Skin Treatments
  {
    id: 'srv-14',
    name: '24K Imperial Gold Collagen Lifting Ritual',
    category: 'Skin Treatments',
    description: 'Pure 24K biological gold sheets massaged with micro-current facial gymnastics to firm contours, stimulate fibroblasts, and impart timeless radiance.',
    price: 190,
    durationMinutes: 90,
    suitableFor: 'Mature, loss of elasticity, or pre-event gala radiance preparation',
    isActive: true,
    featured: false,
    benefits: ['24K pure gold leaf infusion', 'Micro-current lymphatic lift', 'Deep collagen stimulation']
  },

  // Threading
  {
    id: 'srv-15',
    name: 'Couture Brow Architecture & Full Face Threading',
    category: 'Threading',
    description: 'Organic antimicrobial cotton thread technique with golden ratio calipers mapping, followed by soothing rosewater and aloe compresses.',
    price: 35,
    durationMinutes: 30,
    suitableFor: 'Precision eyebrow arch sculpting and gentle facial fuzz removal',
    isActive: true,
    featured: false,
    benefits: ['Calipers brow mapping', 'Hypoallergenic organic thread', 'Soothing rose mist']
  },

  // Waxing
  {
    id: 'srv-16',
    name: 'Italian Rica White Chocolate Body Wax',
    category: 'Waxing',
    description: 'Colophony-free liposoluble Italian wax enriched with cocoa butter and titanium dioxide. Extremely gentle on delicate and sensitive skin.',
    price: 75,
    durationMinutes: 45,
    suitableFor: 'All skin types, especially sensitive skin prone to redness or irritation',
    isActive: true,
    featured: false,
    benefits: ['98% less skin traction', 'Slow hair regrowth', 'Velvety smooth skin feel']
  },

  // Bleach
  {
    id: 'srv-17',
    name: 'Herbal Oxygen De-Tan & Melanin Lightening',
    category: 'Bleach',
    description: 'Gentle fruit enzyme and milk protein de-tanning mask that neutralizes sun tan, reduces dark spots, and unifies tone without harsh stinging.',
    price: 40,
    durationMinutes: 35,
    suitableFor: 'Sun-exposed, tanned, or uneven skin requiring gentle brightening',
    isActive: true,
    featured: false,
    benefits: ['Zero burning sensation', 'Sun tan removal', 'Enriched with lactic proteins']
  },

  // Body Massage
  {
    id: 'srv-18',
    name: 'Deep Tissue Myofascial Release & Hot Volcanic Stone',
    category: 'Body Massage',
    description: 'Targeted deep-pressure strokes combined with warmed basalt volcanic stones to melt chronic muscular knots and restore physical equilibrium.',
    price: 140,
    durationMinutes: 75,
    suitableFor: 'Physical exhaustion, postural strain, muscle soreness, or high stress',
    isActive: true,
    featured: true,
    benefits: ['Volcanic stone heat penetration', 'Myofascial tension unraveling', 'Custom essential oil blend']
  },

  // Spa
  {
    id: 'srv-19',
    name: 'Moroccan Royal Hammam Steam & Eucalyptus Polish',
    category: 'Spa',
    description: 'Private marble steam bath, black olive Beldi soap application, vigorous Kessa mitt body exfoliation, and Ghassoul clay purification.',
    price: 175,
    durationMinutes: 90,
    suitableFor: 'Full-body deep purification, circulation boost, and profound relaxation',
    isActive: true,
    featured: false,
    benefits: ['Authentic Kessa mitt exfoliation', 'Atlas mountain clay wrap', 'Full-body silky skin renewal']
  },

  // Manicure
  {
    id: 'srv-20',
    name: 'Russian Dry Precision E-File Manicure & Gel Overlay',
    category: 'Manicure',
    description: 'Meticulous dry cuticle diamond e-file hardware technique, apex alignment, and non-toxic Japanese gel overlay lasting 4+ weeks with zero chipping.',
    price: 65,
    durationMinutes: 60,
    suitableFor: 'Clients seeking pristine flawless cuticles and chip-free enduring durability',
    isActive: true,
    featured: false,
    benefits: ['Diamond-bit precision contouring', '4+ weeks chip-free guarantee', 'Strengthening keratin base']
  },

  // Pedicure
  {
    id: 'srv-21',
    name: 'Rose Milk & Warm Paraffin Luxury Spa Pedicure',
    category: 'Pedicure',
    description: 'Warm organic milk and Bulgarian rose bath, volcanic pumice callus smoothing, honey sugar scrub, foot massage, and warm paraffin bootie infusion.',
    price: 75,
    durationMinutes: 60,
    suitableFor: 'Tired, dry feet needing deep thermal hydration and immaculate grooming',
    isActive: true,
    featured: false,
    benefits: ['Thermal paraffin bootie soak', 'Cracked heel restoration', 'Aromatherapeutic foot massage']
  },

  // Makeup
  {
    id: 'srv-22',
    name: 'Haute Glamour Red Carpet Evening Makeup',
    category: 'Makeup',
    description: 'Full-glam editorial makeup application including customized mink lashes, contour sculpting, glass skin base, and transfer-proof setting.',
    price: 120,
    durationMinutes: 60,
    suitableFor: 'Galas, cocktail parties, birthdays, and high-profile evening events',
    isActive: true,
    featured: false,
    benefits: ['Airbrush foundation base', 'Individual bespoke lashes', '16-hour transfer-proof wear']
  },

  // Bridal Makeup
  {
    id: 'srv-23',
    name: 'Atelier Royal Couture Bridal Masterpiece',
    category: 'Bridal Makeup',
    description: 'Comprehensive bridal journey including trial consultation, HD waterproof bridal makeup, jewelry placement, couture hair sculpting, and body luminance.',
    price: 350,
    durationMinutes: 150,
    suitableFor: 'Brides seeking royalty-grade perfection for ceremonies and receptions',
    isActive: true,
    featured: true,
    benefits: ['Pre-wedding trial session', 'Luxury touch-up kit included', 'Jewelry & dupatta/veil setting']
  },

  // Grooming
  {
    id: 'srv-24',
    name: 'Gentleman\'s Royal Beard Architecture & Charcoal Facial',
    category: 'Grooming',
    description: 'Hot towel herbal prep, straight-edge razor line sculpting, organic sandalwood beard oil conditioning, and activated charcoal clarifying mask.',
    price: 75,
    durationMinutes: 50,
    suitableFor: 'Gentlemen demanding immaculate facial hair lines and clear energized skin',
    isActive: true,
    featured: false,
    benefits: ['Hot steamed towel ritual', 'Straight razor precision edge', 'Charcoal pore purification']
  }
];

export const INITIAL_STAFF: Staff[] = [
  {
    id: 'stf-1',
    name: 'Julian de Laurent',
    title: 'Creative Director & Master Stylist',
    specialization: 'Haute Haircut, French Balayage & Architectural Bobs',
    bio: 'Former senior stylist at Paris Fashion Week and Vidal Sassoon Academy educator with 16 years of luxury salon leadership.',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    services: ['Haircut', 'Hair Styling', 'Balayage/Ombre', 'Highlights', 'Hair Colour'],
    workingDays: [1, 2, 3, 4, 5],
    workingHours: { start: '09:30', end: '19:00' },
    rating: 4.98,
    reviewsCount: 420,
    isAvailable: true
  },
  {
    id: 'stf-2',
    name: 'Dr. Clara Vance, MD',
    title: 'Chief Aesthetician & Skin Director',
    specialization: 'Hydra MediFacials, 24K Gold Lift & Laser Peels',
    bio: 'Board-certified medical aesthetician specializing in non-invasive dermaceutical rejuvenation, cellular hydration, and sensitive skin restoration.',
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80',
    services: ['Medifacial', 'Facial', 'Skin Treatments', 'Bleach', 'Threading'],
    workingDays: [2, 3, 4, 5, 6],
    workingHours: { start: '10:00', end: '18:30' },
    rating: 4.97,
    reviewsCount: 388,
    isAvailable: true
  },
  {
    id: 'stf-3',
    name: 'Elena Rostova',
    title: 'Master Trichologist & Texture Specialist',
    specialization: 'Nanoplastia, Japanese Straightening & Bond Rebuilding',
    bio: 'Certified trichology specialist and Brazilian nanoplastia pioneer trained in Milan, trusted by models for mirror glass transformations.',
    photoUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=600&q=80',
    services: ['Nanoplastia', 'Hair Straightening', 'Rebonding', 'Hair Treatment', 'Hair Wash'],
    workingDays: [1, 2, 4, 5, 6],
    workingHours: { start: '09:00', end: '18:00' },
    rating: 4.99,
    reviewsCount: 512,
    isAvailable: true
  },
  {
    id: 'stf-4',
    name: 'Aria Thorne',
    title: 'Bridal Artistry & Couture Makeup Lead',
    specialization: 'Couture Bridal, Red Carpet Glam & Airbrush Artistry',
    bio: 'Over a decade styling celebrity red carpets and royal nuptials. Renowned for creating breathless dewy skin with enduring 24-hour perfection.',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80',
    services: ['Bridal Makeup', 'Makeup', 'Hair Styling'],
    workingDays: [3, 4, 5, 6, 0],
    workingHours: { start: '10:00', end: '20:00' },
    rating: 4.96,
    reviewsCount: 295,
    isAvailable: true
  },
  {
    id: 'stf-5',
    name: 'Mateo Rossi',
    title: 'Master Barber & Wellness Specialist',
    specialization: 'Gentleman Grooming, Volcanic Massage & Spa Hammam',
    bio: 'Trained in Florence in traditional straight-razor craftsmanship and holistic body kinesiology, delivering restorative head-to-toe vitality.',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
    services: ['Grooming', 'Body Massage', 'Spa', 'Manicure', 'Pedicure'],
    workingDays: [1, 3, 4, 5, 6],
    workingHours: { start: '10:00', end: '19:30' },
    rating: 4.95,
    reviewsCount: 310,
    isAvailable: true
  }
];

export const INITIAL_OFFERS: SpecialOffer[] = [
  {
    id: 'off-1',
    title: 'The Glass Hair Alchemy Ritual',
    badge: 'Signature Best-Seller',
    description: 'Complete restorative package combining our Pure Organic Nanoplastia, Olaplex molecular bond shield, and caviar scalp massage.',
    originalPrice: 420,
    offerPrice: 329,
    discountPercent: 22,
    includes: [
      'Full Organic Nanoplastia Treatment',
      'Olaplex No. 1 & 2 Molecular Bond Rescue',
      'Caviar Scalp Detox & Hydro Scalp Steam',
      'Complimentary Take-Home Keratin Serum (50ml)'
    ],
    validUntil: '2026-12-31',
    isActive: true
  },
  {
    id: 'off-2',
    title: 'Haute Bridal Pavillion Experience',
    badge: 'Exclusive Bridal Suite',
    description: 'The pinnacle of pre-wedding pampering with complete trial consultation, HD bridal makeup, champagne, and bridal party styling.',
    originalPrice: 580,
    offerPrice: 449,
    discountPercent: 23,
    includes: [
      'Atelier Royal Couture Bridal Makeup & Hair Trial',
      'Wedding Day HD Airbrush & Veil Draping',
      'Hydra-Infusion MediGlow Facial 48h prior',
      'Private VIP Suite with Vintage Champagne & Canapés'
    ],
    validUntil: '2026-11-30',
    isActive: true
  },
  {
    id: 'off-3',
    title: 'Weekday Radiant Glow Sanctuary',
    badge: 'Tuesday – Thursday Only',
    description: 'Rebalance skin and hair mid-week with bespoke Parisian facial massage, precision haircut, and deep conditioning glaze.',
    originalPrice: 225,
    offerPrice: 175,
    discountPercent: 22,
    includes: [
      'Bespoke Haute Haircut & Thermal Finish',
      'Cellular Oxygen Glow Facial',
      'Aromatherapy Scalp & Shoulder Massage',
      'Barista Espresso or Herbal Tisane'
    ],
    validUntil: '2026-12-15',
    isActive: true
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Victoria Sterling',
    serviceName: 'Pure Organic Nanoplastia Glass Hair',
    rating: 5,
    date: '3 days ago',
    comment: 'I fly from Zurich specifically to see Elena for the Nanoplastia. No salon in Europe compares to this level of perfection. My hair is literally like spun liquid glass, completely zero frizz even in high humidity.',
    verified: true,
    avatarText: 'VS'
  },
  {
    id: 'rev-2',
    author: 'Alexander Thorne',
    serviceName: 'Gentleman\'s Royal Grooming & Facial',
    rating: 5,
    date: '1 week ago',
    comment: 'The private grooming suite is phenomenal. Mateo is an absolute artist with the straight razor, and the charcoal facial left my skin feeling totally refreshed before a high-stakes investor pitch.',
    verified: true,
    avatarText: 'AT'
  },
  {
    id: 'rev-3',
    author: 'Camille Beaumont',
    serviceName: 'Hydra-Infusion MediGlow & LED',
    rating: 5,
    date: '2 weeks ago',
    comment: 'Dr. Clara diagnosed my stressed skin immediately. The MediGlow vortex cleanout combined with the red light phototherapy produced results that lasted over a month. Pure luxury and clinical efficacy.',
    verified: true,
    avatarText: 'CB'
  },
  {
    id: 'rev-4',
    author: 'Natasha D\'Souza',
    serviceName: 'French Freehand Balayage & Glaze',
    rating: 5,
    date: '3 weeks ago',
    comment: 'Julian gave me the most seamless, sunlit balayage I have ever had in my life. He takes the time to study your collarbone, eye color, and natural parting. Simply extraordinary.',
    verified: true,
    avatarText: 'ND'
  }
];

export const INITIAL_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-101',
    bookingReference: 'MET-8910',
    customerName: 'Sophie Van Der Bilt',
    customerEmail: 'sophie.vdb@example.com',
    customerPhone: '+1 (555) 349-1120',
    serviceId: 'srv-11',
    serviceName: 'Pure Organic Nanoplastia Glass Hair System',
    staffId: 'stf-3',
    staffName: 'Elena Rostova',
    appointmentDate: new Date().toISOString().split('T')[0],
    appointmentTime: '11:00 AM',
    totalPrice: 310,
    durationMinutes: 210,
    notes: 'Prior highlights on ends, prefers warm green tea upon arrival.',
    status: 'confirmed',
    createdAt: '2026-10-02T14:20:00Z'
  },
  {
    id: 'apt-102',
    bookingReference: 'MET-8914',
    customerName: 'Marcus Kensington',
    customerEmail: 'm.kensington@example.com',
    customerPhone: '+1 (555) 781-9923',
    serviceId: 'srv-24',
    serviceName: 'Gentleman\'s Royal Beard Architecture & Charcoal Facial',
    staffId: 'stf-5',
    staffName: 'Mateo Rossi',
    appointmentDate: new Date().toISOString().split('T')[0],
    appointmentTime: '02:00 PM',
    totalPrice: 75,
    durationMinutes: 50,
    notes: 'Sensitive skin around neck line.',
    status: 'in-progress',
    createdAt: '2026-10-01T09:15:00Z'
  },
  {
    id: 'apt-103',
    bookingReference: 'MET-8918',
    customerName: 'Isabella Fontaine',
    customerEmail: 'isabella.fontaine@example.com',
    customerPhone: '+1 (555) 492-8871',
    serviceId: 'srv-13',
    serviceName: 'Hydra-Infusion MediGlow & Diamond Dermabrasion',
    staffId: 'stf-2',
    staffName: 'Dr. Clara Vance, MD',
    appointmentDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    appointmentTime: '03:30 PM',
    totalPrice: 165,
    durationMinutes: 75,
    notes: 'Pre-wedding skin glow preparation.',
    status: 'confirmed',
    createdAt: '2026-10-03T11:00:00Z'
  }
];
