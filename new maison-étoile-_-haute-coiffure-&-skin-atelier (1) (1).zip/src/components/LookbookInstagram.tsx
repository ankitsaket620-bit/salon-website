import React from 'react';
import { Instagram, ArrowUpRight, Sparkles } from 'lucide-react';

export const LookbookInstagram: React.FC = () => {
  const posts = [
    {
      image: '/src/assets/images/salon_hair_styling_1791083559327.jpg',
      tag: '#HauteBalayage',
      desc: 'Sunlit dimensional ribbons created with freehand French technique and liquid silk glaze.'
    },
    {
      image: '/src/assets/images/salon_transformation_1791083583978.jpg',
      tag: '#GlassHairNanoplastia',
      desc: 'Bio-organic nano amino acid infusion. 100% formaldehyde-free reflective finish.'
    },
    {
      image: '/src/assets/images/salon_skin_medifacial_1791083571953.jpg',
      tag: '#HydraMediGlow',
      desc: 'Dermal purification with diamond micro-exfoliation and medical-grade red phototherapy.'
    },
    {
      image: '/src/assets/images/hero_luxury_salon_1791083543633.jpg',
      tag: '#AtelierSanctuary',
      desc: 'Quiet morning light inside our Suite 100 styling haven. Natural limestone and champagne brass.'
    }
  ];

  return (
    <section className="bg-[#FAF8F3] py-20 border-b border-[#E6E1D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 pb-6 border-b border-[#E2DDD3]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355] mb-1">
              <Instagram className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>The Social Lookbook</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#171614] font-medium">
              Daily Artistry on Display
            </h2>
          </div>

          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 sm:mt-0 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#171614] hover:text-[#8C7355] transition-colors"
          >
            <span>Follow @maisonetoile.atelier</span>
            <ArrowUpRight className="w-4 h-4 text-[#8C7355]" />
          </a>
        </div>

        {/* 4 Editorial Grid Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {posts.map((post, idx) => (
            <div
              key={idx}
              className="group relative rounded-xl overflow-hidden bg-[#EFECE6] border border-[#E0DBD0] aspect-[4/5] shadow-sm cursor-pointer"
            >
              <img
                src={post.image}
                alt={post.tag}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              {/* Bottom text */}
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <span className="text-[11px] font-semibold text-[#E6CBA8] uppercase tracking-wider block mb-1">
                  {post.tag}
                </span>
                <p className="text-xs text-white/90 leading-snug line-clamp-2">
                  {post.desc}
                </p>
              </div>

              {/* Top right icon */}
              <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/40 backdrop-blur flex items-center justify-center text-white/80 group-hover:text-white transition-colors">
                <Instagram className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
