import React from 'react';
import { ArrowRight, Sparkles, Calendar, ShieldCheck, Clock } from 'lucide-react';

interface FinalBookingCtaProps {
  onOpenBooking: () => void;
}

export const FinalBookingCta: React.FC<FinalBookingCtaProps> = ({ onOpenBooking }) => {
  return (
    <section className="bg-[#171614] text-white py-20 relative overflow-hidden border-b border-[#2C2926]">
      {/* Background Ambience */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#C5A880_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-8 text-center relative z-10 space-y-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#2C2926] border border-[#3E3A35] text-xs font-semibold uppercase tracking-[0.2em] text-[#C5A880]">
          <Sparkles className="w-3.5 h-3.5 text-[#C5A880]" />
          <span>Private Appointments</span>
        </div>

        <h2 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-medium tracking-tight leading-tight text-balance">
          Reserve Your Bespoke Atelier Session.
        </h2>

        <p className="text-sm sm:text-base text-[#B8A99A] max-w-xl mx-auto font-normal leading-relaxed">
          Step into our private suites for personalized scalp diagnostics, 
          organic nanoplastia transformations, or clinical hydra medifacials.
        </p>

        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onOpenBooking}
            className="w-full sm:w-auto px-8 py-4 text-xs font-semibold uppercase tracking-wider text-[#171614] bg-[#C5A880] hover:bg-[#D4BC96] active:scale-[0.99] transition-all rounded shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            <Calendar className="w-4 h-4 text-[#171614]" />
            <span>Select Treatment & Time Slot</span>
            <ArrowRight className="w-4 h-4 text-[#171614]" />
          </button>

          <a
            href="tel:+15557892341"
            className="w-full sm:w-auto px-6 py-4 text-xs font-semibold uppercase tracking-wider text-white hover:bg-white/10 border border-[#3E3A35] transition-all rounded text-center"
          >
            Speak with Concierge
          </a>
        </div>

        <div className="pt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-[#8C7355]">
          <span className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            <span>Zero Wait Time · Guaranteed Slot</span>
          </span>
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Complimentary Rescheduling</span>
          </span>
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>VIP Hospitality Included</span>
          </span>
        </div>
      </div>
    </section>
  );
};
