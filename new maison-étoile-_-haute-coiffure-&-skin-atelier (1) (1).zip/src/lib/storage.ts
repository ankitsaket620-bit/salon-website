import { Service, Staff, Appointment, SpecialOffer, Review, ContactMessage, UserProfile, AppointmentStatus } from '../types';
import { INITIAL_SERVICES, INITIAL_STAFF, INITIAL_OFFERS, INITIAL_REVIEWS, INITIAL_APPOINTMENTS } from '../data/initialData';

const STORAGE_KEYS = {
  SERVICES: 'maison_services_v1',
  STAFF: 'maison_staff_v1',
  APPOINTMENTS: 'maison_appointments_v1',
  OFFERS: 'maison_offers_v1',
  REVIEWS: 'maison_reviews_v1',
  CONTACT: 'maison_contact_v1',
  USER: 'maison_user_v1',
  ADMIN_MODE: 'maison_admin_mode_v1'
};

const DEFAULT_TIME_SLOTS = [
  '09:30 AM',
  '10:30 AM',
  '11:30 AM',
  '01:00 PM',
  '02:00 PM',
  '03:30 PM',
  '04:30 PM',
  '05:30 PM',
  '06:30 PM'
];

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (err) {
    console.warn(`Failed to parse storage key ${key}:`, err);
    return fallback;
  }
}

function saveToStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.error(`Failed to save to storage ${key}:`, err);
  }
}

export const SalonStorage = {
  // Services
  getServices: (): Service[] => {
    return loadFromStorage<Service[]>(STORAGE_KEYS.SERVICES, INITIAL_SERVICES);
  },

  saveServices: (services: Service[]) => {
    saveToStorage(STORAGE_KEYS.SERVICES, services);
  },

  addService: (service: Omit<Service, 'id'>): Service => {
    const services = SalonStorage.getServices();
    const newService: Service = {
      ...service,
      id: `srv-${Date.now()}`
    };
    services.unshift(newService);
    SalonStorage.saveServices(services);
    return newService;
  },

  updateService: (updated: Service): void => {
    const services = SalonStorage.getServices();
    const index = services.findIndex((s) => s.id === updated.id);
    if (index !== -1) {
      services[index] = updated;
      SalonStorage.saveServices(services);
    }
  },

  deleteService: (id: string): void => {
    const services = SalonStorage.getServices().filter((s) => s.id !== id);
    SalonStorage.saveServices(services);
  },

  // Staff
  getStaff: (): Staff[] => {
    return loadFromStorage<Staff[]>(STORAGE_KEYS.STAFF, INITIAL_STAFF);
  },

  saveStaff: (staffList: Staff[]) => {
    saveToStorage(STORAGE_KEYS.STAFF, staffList);
  },

  addStaff: (staffMember: Omit<Staff, 'id'>): Staff => {
    const list = SalonStorage.getStaff();
    const newStaff: Staff = {
      ...staffMember,
      id: `stf-${Date.now()}`
    };
    list.push(newStaff);
    SalonStorage.saveStaff(list);
    return newStaff;
  },

  updateStaff: (updated: Staff): void => {
    const list = SalonStorage.getStaff();
    const index = list.findIndex((s) => s.id === updated.id);
    if (index !== -1) {
      list[index] = updated;
      SalonStorage.saveStaff(list);
    }
  },

  deleteStaff: (id: string): void => {
    const list = SalonStorage.getStaff().filter((s) => s.id !== id);
    SalonStorage.saveStaff(list);
  },

  // Appointments
  getAppointments: (): Appointment[] => {
    return loadFromStorage<Appointment[]>(STORAGE_KEYS.APPOINTMENTS, INITIAL_APPOINTMENTS);
  },

  saveAppointments: (appointments: Appointment[]) => {
    saveToStorage(STORAGE_KEYS.APPOINTMENTS, appointments);
  },

  // Double-booking check
  isSlotBooked: (staffId: string, date: string, time: string, excludeAppointmentId?: string): boolean => {
    const appointments = SalonStorage.getAppointments();
    return appointments.some((apt) => {
      if (apt.id === excludeAppointmentId) return false;
      if (apt.status === 'cancelled') return false;
      
      const sameDate = apt.appointmentDate === date;
      const sameTime = apt.appointmentTime === time;
      
      // If a specific staff was booked, check exact match.
      // If 'any-master' was selected or checking for specific staff:
      if (staffId === 'any-master') {
        return sameDate && sameTime;
      }
      return sameDate && sameTime && (apt.staffId === staffId || apt.staffId === 'any-master');
    });
  },

  getAvailableSlots: (staffId: string, date: string, excludeAppointmentId?: string): { time: string; available: boolean }[] => {
    const staffList = SalonStorage.getStaff();
    const staffMember = staffList.find((s) => s.id === staffId);
    
    // Check day of week
    if (staffMember) {
      const dayOfWeek = new Date(date).getDay();
      if (!staffMember.workingDays.includes(dayOfWeek)) {
        return DEFAULT_TIME_SLOTS.map((t) => ({ time: t, available: false }));
      }
    }

    return DEFAULT_TIME_SLOTS.map((time) => {
      const booked = SalonStorage.isSlotBooked(staffId, date, time, excludeAppointmentId);
      return {
        time,
        available: !booked
      };
    });
  },

  createAppointment: (data: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    serviceId: string;
    staffId: string;
    appointmentDate: string;
    appointmentTime: string;
    notes?: string;
  }): { success: boolean; appointment?: Appointment; error?: string } => {
    const services = SalonStorage.getServices();
    const staffList = SalonStorage.getStaff();
    
    const service = services.find((s) => s.id === data.serviceId);
    if (!service) return { success: false, error: 'Selected service not found' };

    let staffName = 'Lead Master Stylist';
    if (data.staffId !== 'any-master') {
      const staff = staffList.find((s) => s.id === data.staffId);
      if (!staff) return { success: false, error: 'Selected stylist not found' };
      staffName = staff.name;
    }

    // Verify slot availability
    if (SalonStorage.isSlotBooked(data.staffId, data.appointmentDate, data.appointmentTime)) {
      return { success: false, error: 'This time slot was just booked by another client. Please select another time.' };
    }

    const newAppointment: Appointment = {
      id: `apt-${Date.now()}`,
      bookingReference: `MET-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      customerPhone: data.customerPhone,
      serviceId: service.id,
      serviceName: service.name,
      staffId: data.staffId,
      staffName,
      appointmentDate: data.appointmentDate,
      appointmentTime: data.appointmentTime,
      totalPrice: service.price,
      durationMinutes: service.durationMinutes,
      notes: data.notes || '',
      status: 'confirmed',
      createdAt: new Date().toISOString()
    };

    const appointments = SalonStorage.getAppointments();
    appointments.unshift(newAppointment);
    SalonStorage.saveAppointments(appointments);

    return { success: true, appointment: newAppointment };
  },

  updateAppointmentStatus: (id: string, status: AppointmentStatus): void => {
    const list = SalonStorage.getAppointments();
    const item = list.find((a) => a.id === id);
    if (item) {
      item.status = status;
      SalonStorage.saveAppointments(list);
    }
  },

  rescheduleAppointment: (id: string, newDate: string, newTime: string): { success: boolean; error?: string } => {
    const list = SalonStorage.getAppointments();
    const item = list.find((a) => a.id === id);
    if (!item) return { success: false, error: 'Appointment not found' };

    if (SalonStorage.isSlotBooked(item.staffId, newDate, newTime, id)) {
      return { success: false, error: 'That slot is currently unavailable for this specialist.' };
    }

    item.appointmentDate = newDate;
    item.appointmentTime = newTime;
    item.status = 'confirmed';
    SalonStorage.saveAppointments(list);
    return { success: true };
  },

  cancelAppointment: (id: string, reason?: string): { success: boolean } => {
    const list = SalonStorage.getAppointments();
    const item = list.find((a) => a.id === id);
    if (item) {
      item.status = 'cancelled';
      if (reason) item.notes = `${item.notes || ''} [Cancelled: ${reason}]`.trim();
      SalonStorage.saveAppointments(list);
    }
    return { success: true };
  },

  // Offers
  getOffers: (): SpecialOffer[] => {
    return loadFromStorage<SpecialOffer[]>(STORAGE_KEYS.OFFERS, INITIAL_OFFERS);
  },

  saveOffers: (offers: SpecialOffer[]) => {
    saveToStorage(STORAGE_KEYS.OFFERS, offers);
  },

  updateOffer: (offer: SpecialOffer) => {
    const list = SalonStorage.getOffers();
    const idx = list.findIndex((o) => o.id === offer.id);
    if (idx !== -1) {
      list[idx] = offer;
      SalonStorage.saveOffers(list);
    }
  },

  // Reviews
  getReviews: (): Review[] => {
    return loadFromStorage<Review[]>(STORAGE_KEYS.REVIEWS, INITIAL_REVIEWS);
  },

  addReview: (review: Omit<Review, 'id' | 'verified'>): Review => {
    const reviews = SalonStorage.getReviews();
    const newRev: Review = {
      ...review,
      id: `rev-${Date.now()}`,
      verified: true,
      avatarText: review.author.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()
    };
    reviews.unshift(newRev);
    saveToStorage(STORAGE_KEYS.REVIEWS, reviews);
    return newRev;
  },

  // Contact Messages
  getContactMessages: (): ContactMessage[] => {
    return loadFromStorage<ContactMessage[]>(STORAGE_KEYS.CONTACT, [
      {
        id: 'msg-1',
        name: 'Genevieve Laurent',
        email: 'g.laurent@luxury.com',
        phone: '+1 (555) 890-4412',
        serviceInterest: 'Atelier Royal Couture Bridal Masterpiece',
        message: 'Inquiring about privatizing the bridal pavilion for a party of 6 on November 14th.',
        createdAt: '2026-10-02T16:45:00Z',
        status: 'unread'
      }
    ]);
  },

  addContactMessage: (msg: Omit<ContactMessage, 'id' | 'createdAt' | 'status'>): ContactMessage => {
    const list = SalonStorage.getContactMessages();
    const newMsg: ContactMessage = {
      ...msg,
      id: `msg-${Date.now()}`,
      createdAt: new Date().toISOString(),
      status: 'unread'
    };
    list.unshift(newMsg);
    saveToStorage(STORAGE_KEYS.CONTACT, list);
    return newMsg;
  },

  updateContactStatus: (id: string, status: 'unread' | 'read' | 'contacted'): void => {
    const list = SalonStorage.getContactMessages();
    const item = list.find((m) => m.id === id);
    if (item) {
      item.status = status;
      saveToStorage(STORAGE_KEYS.CONTACT, list);
    }
  },

  // Auth & Profile
  getCurrentUser: (): UserProfile | null => {
    return loadFromStorage<UserProfile | null>(STORAGE_KEYS.USER, null);
  },

  setCurrentUser: (user: UserProfile | null) => {
    saveToStorage(STORAGE_KEYS.USER, user);
  },

  updateProfile: (updated: Partial<UserProfile>): UserProfile | null => {
    const current = SalonStorage.getCurrentUser();
    if (!current) return null;
    const merged = { ...current, ...updated };
    SalonStorage.setCurrentUser(merged);
    return merged;
  }
};
