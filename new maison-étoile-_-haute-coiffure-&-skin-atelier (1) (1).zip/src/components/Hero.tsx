import React from 'react';
import { ArrowRight, Star, Sparkles, ShieldCheck } from 'lucide-react';

interface HeroProps {
  onOpenBooking: () => void;
  onExploreServices: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking, onExploreServices }) => {
  return (
    <section className="relative bg-[#FDFBF7] pt-8 pb-16 lg:py-20 border-b border-[#E6E1D8] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Editorial Headline & Actions */}
          <div className="lg:col-span-6 flex flex-col items-start space-y-6">
            {/* Editorial Kicker */}
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355]">
              <Sparkles className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>Haute Coiffure & Dermal Atelier</span>
            </div>

            {/* Display Headline */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl leading-[1.08] text-[#171614] text-balance font-medium">
              Where Parisian Craft Meets Clinical Perfection.
            </h1>

            {/* Subtitle / Luxury Description */}
            <p className="text-base sm:text-lg text-[#554F47] leading-relaxed max-w-xl font-normal">
              An intimate sanctuary dedicated to zero-formaldehyde organic Nanoplastia, 
              bespoke French balayage, Hydra-Infusion medifacials, and royal bridal couture. 
              Designed for those who accept nothing less than uncompromising beauty.
            </p>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 w-full sm:w-auto">
              <button
                onClick={onOpenBooking}
                className="px-8 py-3.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] active:scale-[0.99] transition-all rounded shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Reserve Appointment</span>
                <ArrowRight className="w-4 h-4 text-[#C5A880]" />
              </button>

              <button
                onClick={onExploreServices}
                className="px-7 py-3.5 text-xs font-semibold uppercase tracking-wider text-[#171614] hover:bg-[#F2EDE2] border border-[#D9D2C5] transition-all rounded text-center cursor-pointer"
              >
                Explore Services Menu
              </button>
            </div>

            {/* Proof Points Adjacency */}
            <div className="pt-6 border-t border-[#E6E1D8] w-full grid grid-cols-3 gap-4 text-left">
              <div>
                <div className="flex items-center gap-1 text-[#8C7355]">
                  <Star className="w-4 h-4 fill-[#C5A880] text-[#C5A880]" />
                  <span className="font-semibold text-sm text-[#171614]">4.9 / 5.0</span>
                </div>
                <p className="text-xs text-[#70685D] mt-0.5">2,480+ Verified Reviews</p>
              </div>

              <div>
                <span className="font-semibold text-sm text-[#171614]">15+ Artisans</span>
                <p className="text-xs text-[#70685D] mt-0.5">Paris & Milan Certified</p>
              </div>

              <div>
                <span className="font-semibold text-sm text-[#171614]">100% Private</span>
                <p className="text-xs text-[#70685D] mt-0.5">Individual VIP Suites</p>
              </div>
            </div>
          </div>

          {/* Right Column: Dominant Visual Anchor with Scrim & Detail Overlay */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-[#EFECE6] border border-[#E0DBD0] aspect-[16/10] sm:aspect-[16/11]">
              <img
                src="/src/assets/images/hero_luxury_salon_1791083543633.jpg"
                alt="Maison Étoile Luxury Salon Atelier Interior"
                className="w-full h-full object-cover object-center transform hover:scale-[1.01] transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/15 to-transparent pointer-events-none" />

              {/* Bottom Subtle Overlay Note */}
              <div className="absolute bottom-4 left-4 right-4 text-white flex items-center justify-between text-xs backdrop-blur-md bg-black/35 px-4 py-2.5 rounded-lg border border-white/20">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#E6CBA8]" />
                  <span className="font-medium">Medical-Grade Hygiene · Autoclave Sterilization</span>
                </div>
                <span className="text-[#E6CBA8] font-medium hidden sm:inline">Suite 100 Atelier</span>
              </div>
            </div>

            {/* Floating Subtle Accent Card */}
            <div className="hidden sm:block absolute -bottom-6 -left-6 bg-[#FDFBF7] border border-[#D9D2C5] shadow-xl p-4 rounded-xl max-w-xs text-left">
              <p className="text-[11px] uppercase tracking-wider text-[#8C7355] font-semibold">Today's Highlight</p>
              <p className="font-serif text-base font-medium text-[#171614] mt-0.5">Pure Nanoplastia Alchemy</p>
              <p className="text-xs text-[#70685D] mt-1 leading-snug">
                Zero harmful chemicals. Restores damaged cuticle keratin to mirror-reflection silk.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
