import React from 'react';
import { ArrowRight, Check, Sparkles, Tag, Calendar } from 'lucide-react';
import { SpecialOffer } from '../types';

interface PackagesOffersProps {
  offers: SpecialOffer[];
  onBookPackage: (packageTitle: string) => void;
}

export const PackagesOffers: React.FC<PackagesOffersProps> = ({ offers, onBookPackage }) => {
  return (
    <section id="packages" className="bg-[#F8F5EE] py-20 border-b border-[#E6E1D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#E2DDD3]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355] mb-1">
              <Tag className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>Curated Experiences</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#171614] font-medium">
              Signature Atelier Bundles & Seasonal Offers
            </h2>
          </div>
          <p className="text-sm text-[#70685D] max-w-md mt-2 md:mt-0">
            Multi-stage immersive therapies designed for transformational hair health, bridal celebrations, and restorative sanctuary days.
          </p>
        </div>

        {/* Offers Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {offers.map((offer) => (
            <div
              key={offer.id}
              className="bg-[#FDFBF7] rounded-2xl border border-[#D9D2C5] p-7 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between relative overflow-hidden"
            >
              {/* Top Accent Strip */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#C5A880]" />

              <div>
                {/* Badge & Validity */}
                <div className="flex items-center justify-between text-xs mb-3">
                  <span className="text-[#8C7355] font-semibold uppercase tracking-wider text-[11px]">
                    {offer.badge}
                  </span>
                  <span className="flex items-center gap-1 text-[#70685D] text-[11px]">
                    <Calendar className="w-3 h-3 text-[#8C7355]" />
                    <span>Valid until {offer.validUntil}</span>
                  </span>
                </div>

                <h3 className="font-serif text-2xl font-medium text-[#171614] mb-2 leading-snug">
                  {offer.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#665E53] leading-relaxed mb-6">
                  {offer.description}
                </p>

                {/* Inclusions list */}
                <div className="space-y-2.5 py-4 border-t border-b border-[#EFECE6] mb-6">
                  <span className="text-[11px] uppercase tracking-wider text-[#8C7355] font-semibold block">
                    Curated Inclusions:
                  </span>
                  {offer.includes.map((inc, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-[#3E3A35]">
                      <Check className="w-3.5 h-3.5 text-[#8C7355] shrink-0 mt-0.5" />
                      <span>{inc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price & CTA */}
              <div className="pt-2">
                <div className="flex items-baseline gap-3 mb-4">
                  <span className="font-serif text-3xl font-semibold text-[#171614] tabular-nums">
                    ${offer.offerPrice}
                  </span>
                  <span className="text-sm text-[#8C7355] line-through tabular-nums">
                    ${offer.originalPrice}
                  </span>
                  <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Save {offer.discountPercent}%
                  </span>
                </div>

                <button
                  onClick={() => onBookPackage(offer.title)}
                  className="w-full py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] active:scale-[0.98] transition-all rounded shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Reserve Curated Package</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#C5A880]" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
