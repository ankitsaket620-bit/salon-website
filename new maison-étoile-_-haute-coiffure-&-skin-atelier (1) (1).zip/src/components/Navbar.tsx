import React, { useState } from 'react';
import { Calendar, User, Shield, Menu, X, Phone, Clock } from 'lucide-react';
import { UserProfile } from '../types';

interface NavbarProps {
  onOpenBooking: () => void;
  onOpenAccount: () => void;
  onOpenAdmin: () => void;
  onOpenContact?: () => void;
  currentUser: UserProfile | null;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenBooking,
  onOpenAccount,
  onOpenAdmin,
  onOpenContact,
  currentUser
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToContact = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onOpenContact) {
      onOpenContact();
    } else {
      const el = document.getElementById('contact');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Top Quiet Utility Bar */}
      <div className="bg-[#171614] text-[#E6E1D8] text-xs py-2 px-4 sm:px-8 border-b border-[#2C2926]">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-[#B8A99A]">
              <Clock className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>Mon – Sat: 9:00 AM – 8:00 PM · Sun: 10:00 AM – 6:00 PM</span>
            </span>
            <span className="hidden md:inline text-[#B8A99A]">
              Private VIP Suites & Valet Parking Available
            </span>
          </div>

          <div className="flex items-center gap-5">
            <a
              href="tel:+15557892341"
              className="flex items-center gap-1.5 hover:text-[#C5A880] transition-colors whitespace-nowrap"
            >
              <Phone className="w-3 h-3 text-[#C5A880]" />
              <span>Contact: +1 (555) 789-2341</span>
            </a>
            <span className="text-[#3E3A35]">|</span>
            <button
              onClick={onOpenAdmin}
              className="flex items-center gap-1 text-[#B8A99A] hover:text-[#C5A880] transition-colors text-xs font-medium cursor-pointer"
              title="Salon Management Portal"
            >
              <Shield className="w-3 h-3 text-[#C5A880]" />
              <span>Admin Portal</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Strict 3-Zone Luxury Navbar */}
      <header className="sticky top-0 z-40 bg-[#FDFBF7]/95 backdrop-blur-md border-b border-[#E6E1D8] transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 h-20 flex items-center justify-between">
          {/* Zone 1: Single Text Element Brand Wordmark */}
          <a
            href="#"
            className="flex flex-col text-left group"
          >
            <span className="font-serif text-2xl sm:text-3xl font-medium tracking-tight text-[#171614] group-hover:text-[#8C7355] transition-colors">
              Maison Étoile
            </span>
            <span className="text-[10px] tracking-[0.25em] uppercase text-[#8C7355] font-sans font-medium -mt-1">
              Haute Coiffure & Skin
            </span>
          </a>

          {/* Zone 2: 4-6 Clean Text Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#4A453E]">
            <a href="#services" className="hover:text-[#171614] transition-colors">
              Services
            </a>
            <a href="#transformations" className="hover:text-[#171614] transition-colors">
              Before & After
            </a>
            <a href="#packages" className="hover:text-[#171614] transition-colors">
              Rituals
            </a>
            <a href="#team" className="hover:text-[#171614] transition-colors">
              Artisans
            </a>
            <a href="#reviews" className="hover:text-[#171614] transition-colors">
              Reviews
            </a>
            <a href="#location" className="hover:text-[#171614] transition-colors">
              Location
            </a>
            <a
              href="#contact"
              onClick={scrollToContact}
              className="text-[#8C7355] hover:text-[#171614] font-semibold transition-colors flex items-center gap-1"
            >
              <Phone className="w-3 h-3 text-[#C5A880]" />
              <span>Contact Us</span>
            </a>
          </nav>

          {/* Zone 3: 1-2 Primary Action Points */}
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenAccount}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#4A453E] hover:text-[#171614] rounded transition-colors whitespace-nowrap"
            >
              <User className="w-4 h-4 text-[#8C7355]" />
              <span className="hidden sm:inline">
                {currentUser ? currentUser.fullName.split(' ')[0] : 'My Account'}
              </span>
            </button>

            <button
              onClick={onOpenBooking}
              className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] active:scale-[0.98] transition-all rounded shadow-sm flex items-center gap-2 whitespace-nowrap cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>Book Appointment</span>
            </button>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#171614] hover:text-[#8C7355] transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#FDFBF7] border-b border-[#E6E1D8] px-6 py-6 space-y-4 animate-in fade-in duration-200">
            <nav className="flex flex-col space-y-3 text-base font-medium text-[#3E3A35]">
              <a
                href="#services"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#171614] py-1 border-b border-[#F0ECE1]"
              >
                Services Menu
              </a>
              <a
                href="#transformations"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#171614] py-1 border-b border-[#F0ECE1]"
              >
                Before & After Gallery
              </a>
              <a
                href="#packages"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#171614] py-1 border-b border-[#F0ECE1]"
              >
                Curated Packages & Offers
              </a>
              <a
                href="#team"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#171614] py-1 border-b border-[#F0ECE1]"
              >
                Master Artisans
              </a>
              <a
                href="#reviews"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#171614] py-1 border-b border-[#F0ECE1]"
              >
                Verified Testimonials
              </a>
              <a
                href="#location"
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#171614] py-1 border-b border-[#F0ECE1]"
              >
                Location & Hours
              </a>
              <a
                href="#contact"
                onClick={(e) => {
                  setMobileMenuOpen(false);
                  scrollToContact(e);
                }}
                className="hover:text-[#171614] py-1 border-b border-[#F0ECE1] text-[#8C7355] font-semibold flex items-center justify-between"
              >
                <span className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-[#8C7355]" />
                  <span>Contact Us & Inquiries</span>
                </span>
                <span className="text-xs text-[#70685D]">+1 (555) 789-2341</span>
              </a>
            </nav>

            <div className="pt-2 flex flex-col gap-2.5">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] rounded text-center"
              >
                Book Appointment Online
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAccount();
                }}
                className="w-full py-2.5 text-xs font-medium text-[#171614] bg-[#F0ECE1] rounded text-center"
              >
                {currentUser ? `Signed in as ${currentUser.fullName}` : 'Sign In / My Bookings'}
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
