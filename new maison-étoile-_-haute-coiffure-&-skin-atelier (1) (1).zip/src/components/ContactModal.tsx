import React, { useState } from 'react';
import { X, Phone, MessageSquare, Mail, MapPin, Send, CheckCircle2, Clock, Car } from 'lucide-react';
import { SalonStorage } from '../lib/storage';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [serviceInterest, setServiceInterest] = useState('Haircut & Styling');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    SalonStorage.addContactMessage({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      serviceInterest,
      message: message.trim() || 'General inquiry'
    });

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
      setName('');
      setEmail('');
      setPhone('');
      setMessage('');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-[#FDFBF7] border border-[#D9D2C5] rounded-2xl max-w-2xl w-full my-8 shadow-2xl overflow-hidden flex flex-col relative animate-in fade-in zoom-in-95 duration-150 text-left">
        {/* Header */}
        <div className="px-6 py-4 bg-[#FAF8F3] border-b border-[#E6E1D8] flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-[#8C7355] uppercase tracking-wider block">
              Contact & Concierge Desk
            </span>
            <h2 className="font-serif text-2xl font-medium text-[#171614]">
              Connect with Maison Étoile
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#8C7355] hover:text-[#171614] hover:bg-[#F2EDE2] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[75vh] space-y-6">
          {/* Quick Contact Buttons Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <a
              href="tel:+15557892341"
              className="p-4 rounded-xl bg-[#FAF8F3] hover:bg-[#F2EDE2] border border-[#E6E1D8] flex items-center gap-3 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-[#171614] text-[#C5A880] flex items-center justify-center shrink-0">
                <Phone className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[11px] text-[#8C7355] font-semibold block">Telephone</span>
                <span className="font-serif text-lg font-semibold text-[#171614]">+1 (555) 789-2341</span>
              </div>
            </a>

            <a
              href="https://wa.me/15557892341"
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 rounded-xl bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-200 flex items-center gap-3 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-emerald-700 text-white flex items-center justify-center shrink-0">
                <MessageSquare className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[11px] text-emerald-800 font-semibold block">WhatsApp Concierge</span>
                <span className="font-serif text-lg font-semibold text-emerald-950">Chat in Real-Time</span>
              </div>
            </a>
          </div>

          {/* Inquiry Form */}
          <div className="bg-[#FAF8F3] p-5 rounded-xl border border-[#E6E1D8]">
            <h3 className="font-serif text-lg font-medium text-[#171614] mb-1">
              Send an Online Inquiry
            </h3>
            <p className="text-xs text-[#70685D] mb-4">
              We respond to all consultations, bridal requests, and questions within 2 hours.
            </p>

            {submitted ? (
              <div className="py-6 text-center text-emerald-800">
                <CheckCircle2 className="w-10 h-10 mx-auto mb-2 text-emerald-700" />
                <p className="font-semibold text-sm">Inquiry Dispatched Successfully</p>
                <p className="text-xs text-[#70685D] mt-1">Our concierge team will reach out to you shortly.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-[#8C7355] block mb-1">Your Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Sophia Loren"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-[#8C7355] block mb-1">Email Address *</label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. sophia@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-[#8C7355] block mb-1">Phone Number</label>
                    <input
                      type="tel"
                      placeholder="e.g. +1 (555) 000-0000"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm focus:outline-none focus:border-[#8C7355]"
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-[#8C7355] block mb-1">Service or Subject</label>
                    <select
                      value={serviceInterest}
                      onChange={(e) => setServiceInterest(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm focus:outline-none focus:border-[#8C7355]"
                    >
                      <option>Haircut & Bespoke Styling</option>
                      <option>Organic Nanoplastia Alchemy</option>
                      <option>French Balayage & Glaze</option>
                      <option>Clinical Hydra-Infusion Medifacial</option>
                      <option>Bridal Couture Suite & Trials</option>
                      <option>Gentleman's Royal Grooming</option>
                      <option>General Questions & Valet Directions</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-[#8C7355] block mb-1">Message or Questions</label>
                  <textarea
                    rows={3}
                    placeholder="Tell us about desired dates, consultations, or hair history..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D9D2C5] rounded-lg text-sm focus:outline-none focus:border-[#8C7355]"
                  />
                </div>

                <div className="pt-1 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-xs font-medium text-[#70685D]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] rounded hover:bg-[#2C2926] flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5 text-[#C5A880]" />
                    <span>Send Message</span>
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Atelier Details */}
          <div className="space-y-2 text-xs text-[#554F47] pt-2 border-t border-[#E6E1D8]">
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-[#8C7355] shrink-0 mt-0.5" />
              <span>480 Haute Boulevard, Suite 100 · The Promenade Court, Metropolis, NY 10021</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#8C7355] shrink-0" />
              <span>Open Monday – Saturday: 9:00 AM – 8:00 PM · Sunday: 10:00 AM – 6:00 PM</span>
            </div>
            <div className="flex items-center gap-2">
              <Car className="w-4 h-4 text-[#8C7355] shrink-0" />
              <span>Complimentary private underground valet parking at Entrance B</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
