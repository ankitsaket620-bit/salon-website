export type ServiceCategory =
  | 'Haircut'
  | 'Hair Wash'
  | 'Hair Styling'
  | 'Hair Colour'
  | 'Highlights'
  | 'Balayage/Ombre'
  | 'Hair Treatment'
  | 'Hair Straightening'
  | 'Rebonding'
  | 'Nanoplastia'
  | 'Facial'
  | 'Medifacial'
  | 'Skin Treatments'
  | 'Threading'
  | 'Waxing'
  | 'Bleach'
  | 'Body Massage'
  | 'Spa'
  | 'Manicure'
  | 'Pedicure'
  | 'Makeup'
  | 'Bridal Makeup'
  | 'Grooming';

export interface Service {
  id: string;
  name: string;
  category: ServiceCategory;
  description: string;
  price: number;
  durationMinutes: number;
  suitableFor: string;
  isActive: boolean;
  featured?: boolean;
  imageUrl?: string;
  benefits?: string[];
}

export interface Staff {
  id: string;
  name: string;
  title: string;
  specialization: string;
  bio: string;
  photoUrl: string;
  services: string[]; // Service IDs or Categories
  workingDays: number[]; // 0=Sun, 1=Mon, ..., 6=Sat
  workingHours: {
    start: string; // "09:00"
    end: string; // "19:00"
  };
  rating: number;
  reviewsCount: number;
  isAvailable: boolean;
}

export type AppointmentStatus = 'confirmed' | 'in-progress' | 'completed' | 'cancelled';

export interface Appointment {
  id: string;
  bookingReference: string;
  userId?: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  serviceId: string;
  serviceName: string;
  staffId: string;
  staffName: string;
  appointmentDate: string; // YYYY-MM-DD
  appointmentTime: string; // "10:30 AM"
  totalPrice: number;
  durationMinutes: number;
  notes?: string;
  status: AppointmentStatus;
  createdAt: string;
}

export interface SpecialOffer {
  id: string;
  title: string;
  badge: string;
  description: string;
  originalPrice: number;
  offerPrice: number;
  discountPercent: number;
  includes: string[];
  validUntil: string;
  isActive: boolean;
}

export interface Review {
  id: string;
  author: string;
  serviceName: string;
  rating: number;
  date: string;
  comment: string;
  verified: boolean;
  avatarText?: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  serviceInterest: string;
  message: string;
  createdAt: string;
  status: 'unread' | 'read' | 'contacted';
}

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  phone: string;
  role: 'customer' | 'admin';
  avatarUrl?: string;
  hairOrSkinNotes?: string;
  createdAt: string;
}
