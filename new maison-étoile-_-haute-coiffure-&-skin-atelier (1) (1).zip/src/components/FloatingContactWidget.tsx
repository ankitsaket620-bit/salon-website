import React, { useState } from 'react';
import { Phone, MessageCircle, Mail, MapPin, X, Sparkles, Clock } from 'lucide-react';

interface FloatingContactWidgetProps {
  onOpenContactModal: () => void;
}

export const FloatingContactWidget: React.FC<FloatingContactWidgetProps> = ({ onOpenContactModal }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-6 left-6 z-40 text-left">
      {/* Expanded Quick Contact Panel */}
      {isOpen && (
        <div className="mb-3 w-80 bg-[#FDFBF7] border border-[#D9D2C5] rounded-2xl shadow-2xl p-5 text-xs text-[#171614] space-y-3.5 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="flex items-center justify-between pb-2 border-b border-[#EFECE6]">
            <div>
              <span className="text-[10px] font-semibold text-[#8C7355] uppercase tracking-wider block">
                Atelier Concierge
              </span>
              <h4 className="font-serif text-base font-medium text-[#171614]">Direct Contact Desk</h4>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-full text-[#8C7355] hover:text-[#171614] hover:bg-[#F2EDE2]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-[11px] text-[#665E53] leading-relaxed">
            Have questions about a service, private suite buyout, or same-day appointments? Connect with our concierge immediately:
          </p>

          <div className="space-y-2">
            <a
              href="tel:+15557892341"
              className="flex items-center gap-2.5 p-2.5 bg-[#FAF8F3] hover:bg-[#F2EDE2] rounded-xl border border-[#E6E1D8] font-medium text-[#171614] transition-colors"
            >
              <div className="w-7 h-7 rounded-lg bg-[#171614] text-[#C5A880] flex items-center justify-center shrink-0">
                <Phone className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1">
                <span className="block text-[11px] text-[#8C7355]">Telephone Hotline</span>
                <span className="text-xs font-semibold">+1 (555) 789-2341</span>
              </div>
            </a>

            <a
              href="https://wa.me/15557892341"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2.5 p-2.5 bg-emerald-50/70 hover:bg-emerald-100/70 rounded-xl border border-emerald-200 text-emerald-950 font-medium transition-colors"
            >
              <div className="w-7 h-7 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0">
                <MessageCircle className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1">
                <span className="block text-[11px] text-emerald-700">Instant Chat</span>
                <span className="text-xs font-semibold">WhatsApp Concierge</span>
              </div>
            </a>

            <button
              onClick={() => {
                setIsOpen(false);
                onOpenContactModal();
              }}
              className="w-full flex items-center gap-2.5 p-2.5 bg-[#FAF8F3] hover:bg-[#F2EDE2] rounded-xl border border-[#E6E1D8] font-medium text-[#171614] transition-colors text-left"
            >
              <div className="w-7 h-7 rounded-lg bg-[#8C7355] text-white flex items-center justify-center shrink-0">
                <Mail className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1">
                <span className="block text-[11px] text-[#8C7355]">Online Inquiry</span>
                <span className="text-xs font-semibold">Send Concierge Message</span>
              </div>
            </button>
          </div>

          <div className="pt-2 border-t border-[#EFECE6] text-[10px] text-[#70685D] flex items-center gap-1.5">
            <Clock className="w-3 h-3 text-[#8C7355]" />
            <span>Mon–Sat: 9AM–8PM · Sun: 10AM–6PM</span>
          </div>
        </div>
      )}

      {/* Main Floating Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="px-4 py-3 bg-[#171614] text-white hover:bg-[#2C2926] active:scale-95 rounded-full shadow-2xl border border-[#C5A880]/60 flex items-center gap-2.5 text-xs font-semibold tracking-wide transition-all cursor-pointer group"
        aria-label="Contact Concierge"
      >
        <div className="w-5 h-5 rounded-full bg-[#C5A880] text-[#171614] flex items-center justify-center group-hover:rotate-12 transition-transform">
          <Phone className="w-3 h-3" />
        </div>
        <span>Contact Us</span>
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
      </button>
    </div>
  );
};
