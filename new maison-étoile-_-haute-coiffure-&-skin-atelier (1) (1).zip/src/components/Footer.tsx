import React, { useState } from 'react';
import { ArrowRight, Shield, Mail, Phone, MapPin, Instagram, Sparkles, Check } from 'lucide-react';

interface FooterProps {
  onOpenBooking: () => void;
  onOpenAccount: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenBooking, onOpenAccount, onOpenAdmin }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setSubscribed(true);
    setTimeout(() => {
      setNewsletterEmail('');
      setSubscribed(false);
    }, 3000);
  };

  return (
    <footer className="bg-[#171614] text-[#E6E1D8] pt-16 pb-12 border-t border-[#2C2926]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 pb-14 border-b border-[#2C2926]">
          {/* Brand & Editorial Column */}
          <div className="lg:col-span-4 space-y-4 text-left">
            <div>
              <span className="font-serif text-3xl font-medium tracking-tight text-white block">
                Maison Étoile
              </span>
              <span className="text-[10px] tracking-[0.25em] uppercase text-[#C5A880] font-sans font-medium">
                Haute Coiffure & Skin Atelier
              </span>
            </div>

            <p className="text-xs text-[#A89F91] leading-relaxed max-w-sm">
              An intimate sanctuary dedicated to zero-formaldehyde organic Nanoplastia, 
              French freehand balayage, clinical Hydra-Infusion medifacials, and private bridal couture.
            </p>

            <div className="pt-2">
              <button
                onClick={onOpenBooking}
                className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#171614] bg-[#C5A880] hover:bg-[#D4BC96] rounded transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <span>Reserve Consultation</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Quick Menu Links */}
          <div className="lg:col-span-2 space-y-3 text-left">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-[#C5A880]">
              Atelier Menu
            </h4>
            <ul className="space-y-2 text-xs text-[#A89F91]">
              <li>
                <a href="#services" className="hover:text-white transition-colors">Hair Artistry</a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">Nanoplastia Alchemy</a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">Hydra Medifacials</a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">Bridal Couture</a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">Spa & Massage</a>
              </li>
              <li>
                <a href="#packages" className="hover:text-white transition-colors">Curated Rituals</a>
              </li>
            </ul>
          </div>

          {/* Sanctuary Navigation */}
          <div className="lg:col-span-2 space-y-3 text-left">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-[#C5A880]">
              The Sanctuary
            </h4>
            <ul className="space-y-2 text-xs text-[#A89F91]">
              <li>
                <a href="#transformations" className="hover:text-white transition-colors">Before & After</a>
              </li>
              <li>
                <a href="#team" className="hover:text-white transition-colors">Master Artisans</a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-white transition-colors">Verified Reviews</a>
              </li>
              <li>
                <a href="#location" className="hover:text-white transition-colors">Location & Valet</a>
              </li>
              <li>
                <button onClick={onOpenAccount} className="hover:text-white transition-colors text-left">
                  Client Portal
                </button>
              </li>
            </ul>
          </div>

          {/* Newsletter & Concierge Desk */}
          <div className="lg:col-span-4 space-y-4 text-left">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-[#C5A880]">
              Atelier Gazette & Private Invitations
            </h4>
            <p className="text-xs text-[#A89F91]">
              Receive seasonal ritual releases, guest trichology residency notices, and VIP weekend bookings.
            </p>

            {subscribed ? (
              <div className="p-3 bg-emerald-950 border border-emerald-800 text-emerald-300 text-xs rounded flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Thank you. Your address is registered on our private list.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <input
                  type="email"
                  required
                  placeholder="Enter confidential email..."
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="flex-1 px-3 py-2 text-xs bg-[#24211D] border border-[#3E3A35] rounded-lg text-white placeholder-[#70685D] focus:outline-none focus:border-[#C5A880]"
                />
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#171614] bg-white hover:bg-[#EAE4D7] rounded transition-colors cursor-pointer"
                >
                  Join
                </button>
              </form>
            )}

            <div className="pt-2 text-xs text-[#A89F91] space-y-1">
              <p className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#C5A880]" />
                <span>Concierge: +1 (555) 789-2341</span>
              </p>
              <p className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#C5A880]" />
                <span>480 Haute Boulevard, Suite 100, Metropolis</span>
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar with Admin Portal Trigger */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#70685D] gap-4">
          <p>© {new Date().getFullYear()} Maison Étoile Haute Coiffure & Skin Atelier. All rights reserved.</p>

          <div className="flex items-center gap-6">
            <a href="#services" className="hover:text-white transition-colors">Privacy Policy</a>
            <span>·</span>
            <a href="#services" className="hover:text-white transition-colors">Terms of Sanctuary</a>
            <span>·</span>
            <button
              onClick={onOpenAdmin}
              className="text-[#C5A880] hover:text-white transition-colors flex items-center gap-1 font-medium cursor-pointer"
            >
              <Shield className="w-3 h-3 text-[#C5A880]" />
              <span>Admin Management Portal</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
