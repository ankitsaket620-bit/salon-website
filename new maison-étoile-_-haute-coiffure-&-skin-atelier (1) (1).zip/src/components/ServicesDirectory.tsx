import React, { useState, useMemo } from 'react';
import { Search, Clock, ArrowRight, Info, Check, Sparkles, Filter, X } from 'lucide-react';
import { Service, ServiceCategory } from '../types';

interface ServicesDirectoryProps {
  services: Service[];
  onBookService: (serviceId: string) => void;
}

const CATEGORY_GROUPS: { label: string; categories: (ServiceCategory | 'All')[] }[] = [
  { label: 'All Services', categories: ['All'] },
  {
    label: 'Haircut & Styling',
    categories: ['Haircut', 'Hair Wash', 'Hair Styling']
  },
  {
    label: 'Colour & Balayage',
    categories: ['Hair Colour', 'Highlights', 'Balayage/Ombre']
  },
  {
    label: 'Nanoplastia & Straightening',
    categories: ['Nanoplastia', 'Hair Straightening', 'Rebonding', 'Hair Treatment']
  },
  {
    label: 'Clinical Medifacial & Skin',
    categories: ['Medifacial', 'Facial', 'Skin Treatments', 'Bleach']
  },
  {
    label: 'Threading & Waxing',
    categories: ['Threading', 'Waxing']
  },
  {
    label: 'Massage & Spa Rituals',
    categories: ['Body Massage', 'Spa']
  },
  {
    label: 'Nail Atelier',
    categories: ['Manicure', 'Pedicure']
  },
  {
    label: 'Bridal, Glam & Grooming',
    categories: ['Bridal Makeup', 'Makeup', 'Grooming']
  }
];

export const ServicesDirectory: React.FC<ServicesDirectoryProps> = ({ services, onBookService }) => {
  const [selectedGroup, setSelectedGroup] = useState<string>('All Services');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedServiceForModal, setSelectedServiceForModal] = useState<Service | null>(null);

  // Filtered services
  const filteredServices = useMemo(() => {
    return services.filter((srv) => {
      if (!srv.isActive) return false;

      // Group check
      if (selectedGroup !== 'All Services') {
        const group = CATEGORY_GROUPS.find((g) => g.label === selectedGroup);
        if (group && !group.categories.includes(srv.category as any)) {
          return false;
        }
      }

      // Search check
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = srv.name.toLowerCase().includes(q);
        const matchesCat = srv.category.toLowerCase().includes(q);
        const matchesDesc = srv.description.toLowerCase().includes(q);
        const matchesSuit = srv.suitableFor.toLowerCase().includes(q);
        return matchesName || matchesCat || matchesDesc || matchesSuit;
      }

      return true;
    });
  }, [services, selectedGroup, searchQuery]);

  return (
    <section id="services" className="bg-[#FAF8F3] py-20 border-b border-[#E6E1D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-6 border-b border-[#E2DDD3]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#8C7355] mb-1">
              <Sparkles className="w-3.5 h-3.5 text-[#C5A880]" />
              <span>Complete Treatment Portfolio</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#171614] font-medium">
              Curated Services & Dermal Therapies
            </h2>
          </div>
          <p className="text-sm text-[#70685D] max-w-md mt-2 md:mt-0">
            Every session begins with our signature digital scalp & dermal analysis. 
            All formulations are bespoke and mixed tableside.
          </p>
        </div>

        {/* Search & Category Filter Navigation */}
        <div className="space-y-4 mb-10">
          {/* Search Box */}
          <div className="relative max-w-md">
            <Search className="w-4 h-4 text-[#8C7355] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by treatment, concern, or technique..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-[#FDFBF7] border border-[#D9D2C5] rounded-xl text-sm text-[#171614] placeholder-[#9C9488] focus:outline-none focus:border-[#8C7355] shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#8C7355] hover:text-[#171614]"
              >
                Clear
              </button>
            )}
          </div>

          {/* Category Group Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {CATEGORY_GROUPS.map((grp) => (
              <button
                key={grp.label}
                onClick={() => setSelectedGroup(grp.label)}
                className={`px-4 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                  selectedGroup === grp.label
                    ? 'bg-[#171614] text-white shadow-sm'
                    : 'bg-[#F2EDE2] text-[#554F47] hover:bg-[#EAE4D7] hover:text-[#171614] border border-[#E0DBD0]'
                }`}
              >
                {grp.label}
              </button>
            ))}
          </div>
        </div>

        {/* Results Counter */}
        <div className="flex items-center justify-between text-xs text-[#8C7355] font-medium mb-6">
          <span>Showing {filteredServices.length} atelier treatments</span>
          {searchQuery && (
            <span>Filtered by "{searchQuery}"</span>
          )}
        </div>

        {/* Services Grid */}
        {filteredServices.length === 0 ? (
          <div className="bg-[#FDFBF7] border border-dashed border-[#D9D2C5] rounded-2xl p-12 text-center text-[#70685D]">
            <p className="font-serif text-lg text-[#171614]">No treatments match your criteria.</p>
            <p className="text-xs mt-1">Try resetting the search query or selecting a different category.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedGroup('All Services');
              }}
              className="mt-4 px-4 py-2 text-xs font-medium bg-[#171614] text-white rounded-lg"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.map((srv) => (
              <div
                key={srv.id}
                className="bg-[#FDFBF7] rounded-xl border border-[#E6E1D8] p-6 shadow-sm hover:border-[#C5A880]/60 hover:shadow-md transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* Category and duration metadata */}
                  <div className="flex items-center justify-between text-xs text-[#8C7355] font-medium mb-2.5">
                    <span>{srv.category}</span>
                    <span className="flex items-center gap-1 text-[#70685D] tabular-nums">
                      <Clock className="w-3.5 h-3.5 text-[#C5A880]" />
                      <span>{srv.durationMinutes} mins</span>
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-serif text-xl font-medium text-[#171614] group-hover:text-[#8C7355] transition-colors leading-snug mb-2">
                    {srv.name}
                  </h3>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-[#665E53] leading-relaxed line-clamp-3 mb-4">
                    {srv.description}
                  </p>

                  {/* Suitable for indicator */}
                  <div className="bg-[#F8F5EE] px-3 py-2 rounded-lg border border-[#EDE8DE] mb-4">
                    <p className="text-[11px] text-[#70685D] leading-tight">
                      <strong className="text-[#171614] font-medium">Suitable for: </strong>
                      {srv.suitableFor}
                    </p>
                  </div>
                </div>

                {/* Footer with Price & Actions */}
                <div className="pt-4 border-t border-[#EFECE6] flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase tracking-wider text-[#8C7355] font-semibold block">Investment</span>
                    <span className="font-serif text-2xl font-semibold text-[#171614] tabular-nums">
                      ${srv.price}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelectedServiceForModal(srv)}
                      className="p-2 text-[#70685D] hover:text-[#171614] hover:bg-[#F2EDE2] rounded-lg transition-colors cursor-pointer"
                      title="View Treatment Specifications"
                    >
                      <Info className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => onBookService(srv.id)}
                      className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] active:scale-[0.98] transition-all rounded shadow-sm flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>Book Now</span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#C5A880]" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Treatment Specifications Modal */}
        {selectedServiceForModal && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#FDFBF7] border border-[#D9D2C5] rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
              <button
                onClick={() => setSelectedServiceForModal(null)}
                className="absolute top-5 right-5 text-[#8C7355] hover:text-[#171614] p-1.5 rounded-full hover:bg-[#F2EDE2] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="text-xs font-semibold text-[#8C7355] uppercase tracking-wider mb-1">
                {selectedServiceForModal.category}
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl font-medium text-[#171614] mb-3">
                {selectedServiceForModal.name}
              </h3>
              <p className="text-sm text-[#554F47] leading-relaxed mb-6">
                {selectedServiceForModal.description}
              </p>

              <div className="space-y-3.5 border-t border-b border-[#E6E1D8] py-4 my-4 text-xs sm:text-sm">
                <div className="flex justify-between">
                  <span className="text-[#8C7355] font-medium">Treatment Duration</span>
                  <span className="text-[#171614] font-semibold tabular-nums">{selectedServiceForModal.durationMinutes} minutes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8C7355] font-medium">Session Investment</span>
                  <span className="text-[#171614] font-semibold tabular-nums font-serif text-lg">${selectedServiceForModal.price}</span>
                </div>
                <div className="flex flex-col pt-1">
                  <span className="text-[#8C7355] font-medium mb-1">Ideal Client Profile</span>
                  <span className="text-[#3E3A35] bg-[#F5F2EB] p-2.5 rounded-lg border border-[#E6E1D8]">
                    {selectedServiceForModal.suitableFor}
                  </span>
                </div>

                {selectedServiceForModal.benefits && selectedServiceForModal.benefits.length > 0 && (
                  <div className="pt-2">
                    <span className="text-[#8C7355] font-medium block mb-2">Key Ritual Benefits:</span>
                    <ul className="space-y-1.5">
                      {selectedServiceForModal.benefits.map((b, i) => (
                        <li key={i} className="flex items-center gap-2 text-xs text-[#3E3A35]">
                          <Check className="w-3.5 h-3.5 text-[#8C7355] shrink-0" />
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => setSelectedServiceForModal(null)}
                  className="px-4 py-2.5 text-xs font-medium text-[#554F47] hover:text-[#171614]"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const id = selectedServiceForModal.id;
                    setSelectedServiceForModal(null);
                    onBookService(id);
                  }}
                  className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#171614] hover:bg-[#2C2926] rounded shadow flex items-center gap-2"
                >
                  <span>Book Appointment</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#C5A880]" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
